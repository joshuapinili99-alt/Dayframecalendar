# Dayframe Supabase-only setup · v1.9.1

## 1. Create tables and secure policies

1. Open the Supabase project at `https://nkbifjskftalbmorzend.supabase.co`.
2. Go to **SQL Editor → New query**.
3. Paste the contents of `setup.sql` and run it as the project owner.
4. Confirm that `dayframe_events`, `dayframe_folders`, and `dayframe_profiles` exist under `public`, and that the `dayframe-attachments` bucket is **private**.
5. Check the result of the final SQL query. It should list `dayframe_events`, `dayframe_folders`, and `dayframe_profiles` in `supabase_realtime` when Realtime is enabled.

The SQL creates per-user Row Level Security (RLS) policies for planner data, a private attachment bucket, and enables Realtime for the planner and profile tables when the `supabase_realtime` publication exists. The app also uses a 12-second database refresh fallback, but Realtime gives faster cross-device changes. If tables are not listed by the verification query, open **Database → Replication / Publications** or **Integrations → Realtime** in the Supabase Dashboard and enable the three tables for Realtime.

The SQL revokes direct table access from `PUBLIC` and `anon`, then grants access to authenticated users through RLS. Do not disable RLS or add a service-role key to the HTML. If this Supabase project already serves other apps, review existing grants and policies before running it: pre-existing permissive policies can still allow access because permissive policies combine with OR.

## 2. Configure email/password auth

In **Authentication → Sign In / Providers**, enable Email. Decide whether to require email confirmation. If it is enabled, new users must confirm their email before signing in.

In **Authentication → URL Configuration**, set the Site URL to the deployed page. Add the exact GitHub Pages/Netlify URL to Redirect URLs. For a GitHub Pages project site, include the full repo path, for example `https://USERNAME.github.io/REPOSITORY/`.

## 3. Optional Google sign-in

Enable Google under **Authentication → Sign In / Providers** and add the Supabase callback URL shown in its settings to your Google OAuth client. Also include the deployed Dayframe URL in Supabase Redirect URLs.

## 4. Data persistence and checklist

Calendar items, tasks, meetings, notes, and checklist items are stored in `dayframe_events.data` as JSONB. Checklists store their item text, completion state, and IDs in each event. Folders use `dayframe_folders`; profile photo data uses `dayframe_profiles`; attachments use the private Storage bucket. The app retains local recovery data in browser storage and queues unsaved changes when network requests fail.

## 5. Key safety

The embedded key is the Supabase `anon`/public client key. Browsers can read it by design. Its safety depends on RLS and Storage policies. Never place a `service_role` or secret API key in this static website.

## 6. Existing data in a previous cloud account

Supabase accounts and cloud data are separate from a previous cloud provider. This application uses Supabase only. It can recover planner items retained in the local browser cache, but it does not automatically migrate records or accounts stored only in the previous cloud project. Export/import those records separately after mapping each former account to its verified Supabase user.
