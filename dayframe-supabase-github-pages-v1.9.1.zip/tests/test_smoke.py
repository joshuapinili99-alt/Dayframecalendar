"""Playwright smoke tests for Dayframe Supabase edition.

Uses a simulated Supabase client. Does not connect to or modify the live project.
Run with: python -m pip install playwright; install a Chromium browser; python tests/test_smoke.py
"""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
mock = (ROOT / 'tests' / 'mock-supabase.js').read_text(encoding='utf-8')
sw_source = (ROOT / 'sw.js').read_text(encoding='utf-8')
html, count = re.subn(r'<script src="https://cdn\.jsdelivr\.net/npm/@supabase/supabase-js@2\.110\.6"></script>', '<script>' + mock + '</script>', html, count=1)
if count != 1:
    raise RuntimeError('Could not inject simulated Supabase SDK')

RESULTS = []
def check(name, condition):
    RESULTS.append((name, bool(condition)))

with sync_playwright() as p:
    browser_path = '/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None
    browser = p.chromium.launch(executable_path=browser_path, headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
    context = browser.new_context(viewport={'width': 1280, 'height': 900}, service_workers='block')
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(html, wait_until='domcontentloaded')
    page.wait_for_selector('#app:not(.hidden)', timeout=10000)
    page.wait_for_selector('.calendar-grid', timeout=10000)
    page.wait_for_function("document.querySelector('#sync-status').textContent.toLowerCase().includes('synced')", timeout=8000)

    legacy_terms = ['fire' + 'base', 'fire' + 'store', 'init' + 'Fire' + 'base', 'onSnapshot']
    check('retired backend references are absent from the active app', not any(term.lower() in html.lower() for term in legacy_terms))
    original_html = (ROOT / 'index.html').read_text(encoding='utf-8')
    script_sources = re.findall(r'<script[^>]+src=[\"\']([^\"\']+)', original_html, re.I)
    check('Supabase is the only database SDK loaded by the app', any('@supabase/supabase-js' in src for src in script_sources) and all('@supabase/supabase-js' in src or 'heic2any' in src for src in script_sources))
    check('Supabase project URL is configured', "https://nkbifjskftalbmorzend.supabase.co" in html)
    check('exact REST endpoint from attached note is configured', "const SUPABASE_REST_URL='https://nkbifjskftalbmorzend.supabase.co/rest/v1/'" in html)
    check('Supabase JS client root URL is derived correctly from the REST endpoint', "const SUPABASE_URL=SUPABASE_REST_URL.replace(/\\/rest\\/v1\\/?$/,'')" in html)
    check('Supabase JS client is pinned to a specific CDN version', 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.110.6' in (ROOT / 'index.html').read_text(encoding='utf-8'))
    check('password recovery modal has a Supabase password-update flow', 'showPasswordRecoveryModal' in html and 'auth.updateUser({password:next})' in html)
    check('Supabase anon key is embedded with public-client configuration', "SUPABASE_ANON_KEY='eyJhbGciOiJIUzI1Ni" in html and 'service_role' not in html)
    check('desktop calendar renders', page.locator('.calendar-grid').count() == 1)
    check('date-specific quick-add buttons render', page.locator('.calendar-grid .day-add').count() == 42)
    check('visible syncing wording is removed', not page.locator('#sync-status').is_visible() and 'syncing' not in page.locator('body').inner_text().lower())
    check('service worker cache version updated for this release', 'dayframe-shell-v1.9.1' in sw_source)

    # Save a planner item through the mocked Supabase Postgres API.
    add = page.locator('.calendar-grid .day-add').first
    chosen_date = add.get_attribute('data-event-date')
    add.click()
    page.wait_for_selector('#event-form')
    check('quick add preselects selected date', page.locator('#event-form [name=date]').input_value() == chosen_date)
    page.locator('#event-title').fill('Supabase save check')
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Supabase save check')", timeout=8000)
    check('task persists to Supabase event table adapter', True)

    # Profile image should be compressed and written to the private profile row, not Storage.
    icon = str(ROOT / 'icons' / 'icon-512.png')
    page.locator('#profile-upload').set_input_files(icon)
    page.wait_for_function("window.__mockDayframe.data.profiles.size > 0", timeout=10000)
    page.wait_for_function("!document.querySelector('#avatar-image').classList.contains('hidden')", timeout=5000)
    profile_row = page.evaluate("[...window.__mockDayframe.data.profiles.values()][0]")
    check('profile picture is saved as a compressed Supabase profile value', bool(profile_row and str(profile_row.get('avatar_data_url','')).startswith('data:image/')))
    check('profile picture stays near the 440 KB compression target', bool(profile_row and len(profile_row.get('avatar_data_url','')) < 620000))
    check('profile photo does not upload to the attachment bucket', page.evaluate('window.__mockDayframe.storageObjects.size') == 0)

    # Recover after a temporary RLS/API rejection: local pending avatar remains until retry succeeds.
    page.evaluate('window.__mockDayframe.failProfileOnce = true')
    page.locator('#profile-upload').set_input_files(icon)
    pending_key = 'dayframe-avatar-pending-v1-' + page.evaluate('window.__mockDayframe.user.id')
    page.wait_for_function("key => Boolean(window.__mockDayframe.indexedRecords.get(key)?.value?.dataUrl)", arg=pending_key, timeout=10000)
    check('failed avatar cloud write remains queued in IndexedDB', page.evaluate("key => Boolean(window.__mockDayframe.indexedRecords.get(key)?.value?.dataUrl)", pending_key))
    page.evaluate("window.dispatchEvent(new Event('online'))")
    page.wait_for_function("!window.__mockDayframe.indexedRecords.has('dayframe-avatar-pending-v1-' + window.__mockDayframe.user.id)", timeout=8000)
    check('queued profile photo retries and clears after simulated success', page.evaluate("window.__mockDayframe.data.profiles.size > 0 && !window.__mockDayframe.indexedRecords.has('dayframe-avatar-pending-v1-' + window.__mockDayframe.user.id)"))

    # Test attachment upload and private signed URL creation.
    page.locator('.calendar-grid .day-add').first.click()
    page.wait_for_selector('#event-form')
    page.locator('#event-title').fill('Attachment test')
    page.locator('#event-files').set_input_files({'name': 'sample.txt', 'mimeType': 'text/plain', 'buffer': b'Dayframe private attachment test'})
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Attachment test' && (r.data.attachments||[]).some(a => a.storagePath && a.url))", timeout=10000)
    check('attachment uploads use Supabase Storage and private signed URLs', page.evaluate("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Attachment test' && (r.data.attachments||[]).some(a => a.storagePath && a.url.includes('mock-supabase.invalid')))"))
    check('uploaded attachment object is kept in the simulated private bucket', page.evaluate('window.__mockDayframe.storageObjects.size > 0'))

    # Force a transient database failure and test recovery after reconnecting.
    page.evaluate('window.__mockDayframe.failLocalStorage = true; window.__mockDayframe.failNextEventsOnce = true')
    page.locator('[data-view="Tasks"]').click()
    page.locator('.page-heading [data-new-event="task"]').click()
    page.wait_for_selector('#event-form')
    page.locator('#event-title').fill('Recovery test')
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("window.__mockDayframe.failNextEventsOnce === false", timeout=8000)
    page.wait_for_function("Boolean(window.__mockDayframe.indexedRecords.get('dayframe-pending-v1-' + window.__mockDayframe.user.id)?.value?.some(x => x.data?.title === 'Recovery test'))", timeout=8000)
    check('offline/error path retains durable pending task queue when localStorage fails', page.evaluate("Boolean(window.__mockDayframe.indexedRecords.get('dayframe-pending-v1-' + window.__mockDayframe.user.id)?.value?.some(x => x.data?.title === 'Recovery test'))"))
    page.evaluate("window.dispatchEvent(new Event('online'))")
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Recovery test')", timeout=9000)
    check('pending task synchronizes after reconnection', True)


    # Checklist is a first-class planner item and individual checklist rows persist.
    page.locator('[data-view="Checklist"]').click()
    page.locator('.page-heading [data-new-event="checklist"]').click()
    page.wait_for_selector('#event-form')
    page.locator('#event-title').fill('Checklist save check')
    page.locator('#event-checklist-items').fill('[ ] Prepare materials\n[x] Draft introduction')
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Checklist save check' && r.data?.kind === 'checklist' && r.data?.checklistItems?.length === 2)", timeout=8000)
    check('checklist type and each checklist row persist in the database record', page.evaluate("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Checklist save check' && r.data?.checklistItems?.length === 2 && r.data.checklistItems[1].done === true)"))
    page.locator('[data-toggle-checklist-item][data-checklist-index="0"]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Checklist save check' && r.data?.checklistItems?.[0]?.done === true)", timeout=8000)
    check('individual checklist toggle is saved to Supabase', True)

    # Calendar scale should be smaller and every other planner view should be larger.
    page.locator('[data-view="Calendar"]').click()
    check('calendar view uses 80 percent workspace zoom', page.locator('#workspace .workspace-content').evaluate("el => getComputedStyle(el).zoom === '0.8'"))
    page.locator('[data-view="Tasks"]').click()
    check('non-calendar views use 110 percent workspace zoom', page.locator('#workspace .workspace-content').evaluate("el => getComputedStyle(el).zoom === '1.1'"))

    # Notes view is a searchable, autosaving editor with pin support.
    page.locator('[data-view="Notes"]').click()
    page.locator('#notes-new').click()
    page.wait_for_selector('#note-editor-title')
    page.locator('#note-editor-title').fill('Apple-style Notes Test')
    page.locator('#note-editor-body').fill('A body that autosaves to the database.')
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Apple-style Notes Test' && r.data?.notes === 'A body that autosaves to the database.')", timeout=8000)
    check('Notes title and body autosave to the Supabase record', True)
    page.locator('[data-note-pin]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Apple-style Notes Test' && r.data?.isPinned === true)", timeout=8000)
    check('Notes can be pinned and pin state persists', True)
    page.locator('#notes-search').fill('Apple-style')
    check('Notes search filters the note list', page.locator('[data-note-card]').count() == 1)

    # Reminder options are saved with the calendar item. Permission remains opt-in.
    page.locator('[data-view="Calendar"]').click()
    page.locator('.calendar-grid .day-add').first.click()
    page.wait_for_selector('#event-form')
    page.locator('#event-title').fill('Reminder persistence check')
    page.locator('#event-form [name="reminderMinutes"]').select_option('60')
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Reminder persistence check' && r.data?.reminderMinutes === 60)", timeout=8000)
    check('due-date reminder preference persists with the planner item', True)
    check('due reminder permission is opt-in and reminder checker is included', 'Notification.requestPermission()' in html and 'checkDueReminders' in html)

    # Realtime refresh behavior for another simulated device.
    page.locator('[data-view="Tasks"]').click()
    page.evaluate("window.__mockDayframe.injectEvent({id:'external-item-1',title:'Other device event',date:new Date().toISOString().slice(0,10),kind:'task',priority:'normal',attachments:[],updatedAt:new Date().toISOString()})")
    page.wait_for_function("document.body.innerText.includes('Other device event')", timeout=8000)
    check('realtime external changes update the UI', True)

    # A stale network read must never replace a record saved while that read was in flight.
    page.evaluate("window.__mockDayframe.delayNextSelectOnce = true; window.dispatchEvent(new Event('focus'))")
    page.wait_for_timeout(40)
    page.locator('.page-heading [data-new-event="task"]').click()
    page.wait_for_selector('#event-form')
    page.locator('#event-title').fill('Save survives slow refresh')
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Save survives slow refresh')", timeout=8000)
    page.wait_for_timeout(450)
    check('slow stale cloud response cannot overwrite a newly saved record', page.evaluate("document.body.innerText.includes('Save survives slow refresh') && [...window.__mockDayframe.data.events.values()].some(r => r.data?.title === 'Save survives slow refresh')"))

    # If Realtime is unavailable, periodic database refresh should still update this device.
    page.evaluate("window.__mockDayframe.disableRealtime = true; window.__mockDayframe.injectEvent({id:'poll-fallback-event',title:'Polling fallback event',date:new Date().toISOString().slice(0,10),kind:'task',priority:'normal',attachments:[],updatedAt:new Date().toISOString()})")
    page.wait_for_function("document.body.innerText.includes('Polling fallback event')", timeout=16000)
    check('periodic database polling refreshes remote changes without Realtime', True)

    # Sign-out and email login use Supabase Auth client calls.
    page.locator('#signout-button').click()
    page.wait_for_selector('#auth-screen:not(.hidden)', timeout=5000)
    page.locator('#auth-email').fill('taylor@example.com')
    page.locator('#auth-password').fill('sample-password')
    page.locator('#auth-form button[type=submit]').click()
    page.wait_for_selector('#app:not(.hidden)', timeout=8000)
    check('email/password login returns through Supabase Auth', True)

    # Mobile layout and controls.
    page.set_viewport_size({'width': 390, 'height': 844})
    page.wait_for_timeout(120)
    overflow = page.evaluate('document.documentElement.scrollWidth > document.documentElement.clientWidth + 2')
    check('mobile view has no horizontal page overflow', not overflow)
    check('mobile layout hides sync status wording', not page.locator('#sync-status').is_visible())
    check('mobile navigation toggle exists', page.locator('#mobile-menu').count() == 1)
    page.locator('#mobile-menu').click()
    page.locator('[data-view="Tasks"]').click()
    page.wait_for_function("document.body.innerText.includes('Other device event')", timeout=8000)
    check('remote desktop task appears in the mobile task list', True)
    check('mobile non-calendar view keeps 110 percent zoom without horizontal overflow', page.locator('#workspace .workspace-content').evaluate("el => getComputedStyle(el).zoom === '1.1'") and page.evaluate('document.documentElement.scrollWidth <= document.documentElement.clientWidth + 2'))
    page.locator('#mobile-menu').click()
    page.locator('[data-view="Calendar"]').click()
    check('mobile calendar uses 80 percent zoom without page overflow', page.locator('#workspace .workspace-content').evaluate("el => getComputedStyle(el).zoom === '0.8'") and page.evaluate('document.documentElement.scrollWidth <= document.documentElement.clientWidth + 2'))
    page.locator('#mobile-menu').click()
    page.locator('[data-view="Notes"]').click()
    check('mobile Notes list/editor layout remains within viewport', page.evaluate('document.documentElement.scrollWidth <= document.documentElement.clientWidth + 2'))
    page.locator('[data-note-card]').first.click()
    check('mobile Notes editor opens with a back-to-list control', page.locator('#workspace').evaluate("el => el.classList.contains('notes-mobile-editor')") and page.locator('[data-notes-back]').is_visible())
    page.locator('[data-notes-back]').click()
    check('mobile Notes list view returns correctly', not page.locator('#workspace').evaluate("el => el.classList.contains('notes-mobile-editor')"))
    page.locator('#toast').evaluate("el => el.classList.add('hidden')")
    page.screenshot(path=str(ROOT / 'tests' / 'mobile-preview.png'), full_page=True)
    page.set_viewport_size({'width': 1280, 'height': 900})
    page.screenshot(path=str(ROOT / 'tests' / 'desktop-preview.png'), full_page=True)

    check('no page-level JavaScript runtime errors', len(errors) == 0)
    browser.close()

failed = [name for name, ok in RESULTS if not ok]
for name, ok in RESULTS:
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'\n{len(RESULTS)-len(failed)}/{len(RESULTS)} checks passed')
(ROOT / 'tests' / 'TEST-RESULTS.md').write_text("# Automated smoke-test results\n\n" + '\n'.join(f"{'PASS' if ok else 'FAIL'}: {name}" for name, ok in RESULTS) + f"\n\n**Result: {len(RESULTS)-len(failed)}/{len(RESULTS)} passed.**\n\nTests use a simulated Supabase client and do not verify the live project's schema, RLS policies, OAuth provider configuration, storage policies, or actual cross-device network behavior.\n", encoding='utf-8')
if failed:
    raise SystemExit('Smoke checks failed: ' + '; '.join(failed))
