# Dayframe v1.9.4 · Supabase-only edition

Dayframe is a responsive personal planner with Calendar, To-do lists, **Checklists**, Meetings, Notes, Completed items, subject folders, compressed profile photos, and private file attachments. This release improves cross-device updates and save reliability, and removes the visible status text about syncing.

## GitHub Pages deployment

1. Extract the GitHub deployment ZIP. Its files are already arranged for the repository root; upload all extracted files and folders (including the hidden `.github` folder) to the root of a new GitHub repository.
2. Commit and push the files to `main`.
3. In GitHub, open **Settings → Pages** and select **GitHub Actions** as the build/deploy source.
4. Wait for `.github/workflows/deploy-pages.yml` to finish; then open the Pages URL.
5. Follow `supabase-setup/README.md` and run `supabase-setup/setup.sql` in the matching Supabase project. Configure the deployed page URL in Supabase Auth Redirect URLs.

The exact REST endpoint supplied by the owner (`https://nkbifjskftalbmorzend.supabase.co/rest/v1/`) is configured as `SUPABASE_REST_URL` in `index.html`. The client root `SUPABASE_URL` is derived by removing `/rest/v1/`, because `supabase-js` expects the project root rather than the REST endpoint. The browser-safe `anon` public client key is also configured there. Never put a `service_role` or secret API key in browser code.

## Required Supabase setup

Open the project's **SQL Editor**, paste `supabase-setup/setup.sql`, and run it as project owner. It creates the single table `public.dayframe`; enables owner-only Row Level Security (RLS); creates a private `dayframe-attachments` bucket with user-scoped Storage policies; and adds `public.dayframe` to the `supabase_realtime` publication where that publication exists. It also migrates rows from the older `dayframe_events`, `dayframe_folders`, and `dayframe_profiles` tables when they are present.

To check Realtime membership, run the final verification query in `setup.sql`. If the publication is unavailable or Realtime is not enabled, the app also polls the database every 12 seconds while the page is open and active.

Configure **Authentication → URL Configuration** with the deployed site URL and allowed redirect URLs. Enable the Email provider. Google login additionally requires OAuth credentials in Supabase and the Google provider console.

## Supabase-only architecture and improvements in v1.9.1

- **Cross-device update reliability:** Realtime subscriptions are used when available, with 12-second database polling, focus/visibility refresh, and refresh sequencing as fallback protection.
- **Stale-read protection:** A cloud response started before a newer local edit is discarded rather than overwriting that edit.
- **Local recovery:** Writes are persisted into a per-user pending queue and IndexedDB backup. On first successful cloud read after upgrading, local-only records from older versions are recovered to the database. After a successful cloud snapshot is recorded, later remote deletions are not re-created from stale caches.
- **Checklist view:** Create a checklist, store one item per line, mark individual steps complete, and save the checklist to the same per-user planner database record.
- **No visible syncing label:** Background updates continue without showing the sync-status wording in the header. Save confirmations are concise; cloud write failures still notify the user and retain pending data when possible.
- **View scaling:** Calendar is rendered at 80% interface scale; Tasks, Checklists, Meetings, Notes, Completed, and Folders use 110% scale. Scaling is applied to an inner content wrapper so wider modes do not expand the page or cover the date-details panel.
- **Apple Notes-style editor:** Notes uses a searchable note list and a distraction-free title/body editor, pinning, mobile list/editor navigation, and debounced local/cloud autosave. Each note remains a planner record in Supabase.
- **Due-date reminders:** Items can request reminders at the due time, 10 minutes before, 1 hour before, or 1 day before. After a user explicitly enables browser notifications, reminders are shown while Dayframe is open and the page is active. Browser notifications do not reliably fire after the app is closed; background delivery requires a Supabase Edge Function/Cron plus Web Push or email.
- **Mobile refresh and draft protection:** Uses `document.visibilitychange` and `pageshow` to reload cloud records when returning to a phone browser; active Notes drafts are protected from older cloud snapshots and autosaved without interrupting typing.
- **Profile pictures:** Compressed to about 440 KiB or less and stored in a user-owned `public.dayframe` row with `record_type = 'profile'`.
- **Attachments:** Stored in a private bucket and opened using signed URLs valid for seven days.

Planner items and checklists, folders, and profile pictures are stored in `public.dayframe`. The `record_type` column distinguishes `event`, `folder`, and `profile` rows; JSONB planner/folder content uses `data`, and profile pictures use `avatar_data_url`. Attachments remain in the private Supabase Storage bucket. Cosmetic preferences such as theme and background remain on the device; planner content, folders, profile photos, and attachments use the Supabase account backend.

## Public key safety

The embedded key uses the `anon` role and is intended for client use. Anyone can read a key shipped to a browser; RLS and Storage policies must be configured correctly. Review `setup.sql`, keep RLS enabled, and do not add a service-role key to this app. If this Supabase project has broad `PUBLIC` grants or permissive policies from another application, review those too; permissive policies combine.

## Data migration note

Accounts and cloud records from a previous backend do not automatically appear in Supabase. This release can recover planner items left only in the older **local browser cache** when it performs its first successful cloud read, but it cannot import records that exist only in the previous cloud project. Export and import those records separately after verifying which destination Supabase user owns each record.

## Backend scope

Supabase is the only remote backend in this package: Supabase Auth handles sign-in, the `public.dayframe` Postgres table stores planner items, folders, and profile metadata, and Supabase Storage stores attachments. IndexedDB/localStorage are local resilience layers, not a second cloud database. Cosmetic appearance preferences remain device-specific.

## Automated verification

Run `python tests/test_smoke.py` with Python, Playwright, and Chromium. The simulated browser suite currently passes **the automated smoke-test suite**, including an audit of loaded backend SDKs, stale-response protection, a no-Realtime polling fallback, checklist persistence, profile-photo recovery, attachment flow, and mobile overflow checks.

These are front-end tests using a simulated Supabase service. They cannot prove that the live project's SQL, Auth redirects, RLS rules, Storage permissions, internet conditions, or real iPhone/Android behavior are correct. Run the setup SQL and verify saving/refreshing on both a laptop and a phone before depending on cloud storage.


## Due-date reminders

Each user can enable browser notifications through the **Due-date reminders** navigation option, then choose a reminder offset when creating/editing a task, meeting, or planner item. In the static website release, reminders are evaluated while the app tab is open and active. For notifications when a browser is closed, implement and configure server-side scheduled jobs and Web Push subscriptions (or email reminders); a static page alone cannot guarantee closed-app delivery.

## Notes workflow

The Notes view provides a searchable note list, pinned notes, title and body editor, keyboard input, and autosave. Local drafts update immediately, then queue the database write after a short debounce. Background database refreshes do not rebuild the editor while the title or body is focused, preventing interrupted typing. A network or RLS error may delay cloud persistence, so verify the deployed Supabase project and check for a save warning if a draft is not visible on the other device.


## Fix: `Could not find the table 'public.dayframe' in the schema cache`

Run `supabase-setup/setup.sql` in the SQL Editor of the exact Supabase project configured in `index.html`. This setup creates `public.dayframe`, migrates rows from legacy Dayframe tables if present, and sends `NOTIFY pgrst, 'reload schema'` to refresh the API schema cache. If needed, run `FIX-DAYFRAME-SCHEMA-CACHE.sql`. Wait a few seconds, hard-refresh the deployed website, and retry. If the error persists even though the table exists, check Project Settings → API → Exposed schemas includes `public`, and ensure you are using the same Supabase project URL as the deployed app.
