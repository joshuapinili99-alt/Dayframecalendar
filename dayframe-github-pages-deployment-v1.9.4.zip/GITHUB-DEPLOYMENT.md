# Deploy Dayframe to GitHub Pages

This package is prepared for a GitHub repository. The ZIP contains `index.html`, the assets, and the `.github/workflows/deploy-pages.yml` workflow at the archive root.

## 1. Add the files to GitHub

1. Create a new GitHub repository.
2. Extract this ZIP on your computer.
3. Upload **all files and folders inside the ZIP** to the repository root. Make sure the hidden `.github` folder and its `workflows/deploy-pages.yml` file are included.
4. Commit the files to the `main` branch.

For reliable workflow detection, use Git on your computer if the web uploader does not show hidden folders. From the extracted project directory, you can run:

```bash
git init
git add -A
git commit -m "Deploy Dayframe v1.9.4"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the example repository URL with your own. Do not commit any Supabase service-role or secret key.

## 2. Enable GitHub Pages

In the repository, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**. Open **Actions** and check that `Deploy Dayframe to GitHub Pages` finishes successfully. The site URL will be shown in the workflow deployment summary and in Settings → Pages.

## 3. Configure Supabase

In the same Supabase project configured in `index.html`, open **SQL Editor**, run `supabase-setup/setup.sql`, and check that `public.dayframe` exists. Configure Supabase Authentication URL settings with the deployed GitHub Pages URL and the allowed redirect URLs. The setup SQL also configures the private attachment bucket and owner-scoped database/storage policies.

## Important notes

- This is a static GitHub Pages site; the workflow publishes `index.html`, `manifest.webmanifest`, `sw.js`, and `icons/`.
- The browser-visible Supabase anon/public key is intended for frontend use. Never place a Supabase `service_role` key in `index.html`.
- Automated smoke tests use a simulated Supabase service. Verify sign-in, save, refresh, and cross-device sync against your live Supabase project after deployment.
