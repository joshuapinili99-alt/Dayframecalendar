"""Static regression checks for Dayframe v1.14.3 interaction improvements.

These checks validate source wiring and syntax, not live Firebase or physical-device behavior.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
sw = (ROOT / 'sw.js').read_text(encoding='utf-8')
workflow = (ROOT / '.github/workflows/deploy-pages.yml').read_text(encoding='utf-8')
notes = (ROOT / 'RELEASE-NOTES-v1.14.3.md').read_text(encoding='utf-8')
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

check('HTML, service worker, and GitHub workflow use v1.14.4', '<meta name="dayframe-version" content="1.14.4">' in html and "const VERSION='1.14.4'" in sw and 'content="1.14.4"' in workflow)
check('Native window.confirm dependency is removed from delete flow', not re.search(r'(?<![A-Za-z])confirm\s*\(', html) and 'function showAppConfirm(' in html)
check('Item deletion uses a visible app dialog with Cancel and Delete actions', all(token in html for token in ['id="dayframe-confirm-layer"', 'data-confirm-cancel', 'data-confirm-accept', 'function commitDeleteEvent(id)', "saveLocalRecord('events',id,'delete')"]))
check('Folder deletion uses the same safe confirmation dialog', 'function commitDeleteFolder(id)' in html and "onConfirm:()=>commitDeleteFolder(id)" in html)
check('Cancelling a note delete does not clear the active note editor first', "if(b.hasAttribute('data-note-delete')){await deleteEvent(b.dataset.noteDelete);return}" in html)
check('Checklist view creates immediately without the full event modal', "state.view==='Checklist'?'<button class=\"primary-button\" type=\"button\" data-create-checklist>＋ New checklist</button>'" in html and 'function createQuickChecklist()' in html)
check('Quick checklist is saved through the normal local-first Firebase write path', "saveLocalRecord('events',id,'set',item);renderWorkspace();renderDetails();notify('Checklist created. Add your first step below.')" in html)
check('Checklist items can be added inline and saved without opening the edit modal', 'data-add-checklist-item=' in html and 'function addChecklistItem(id,rawText)' in html and 'data-checklist-input=' in html)
check('Inline checklist submit handler prevents form navigation and routes to addChecklistItem', "document.addEventListener('submit',e=>{const form=e.target.closest('form[data-add-checklist-item]')" in html and 'addChecklistItem(id,text)' in html)
check('In-app due reminder function works independently of OS notification permission', 'function showDueReminderCard(item,key,minutes)' in html and "const visible=document.visibilityState!=='hidden',canNotifySystem='Notification' in window&&Notification.permission==='granted'" in html and 'if(!visible&&!canNotifySystem)continue' in html and 'showDueReminderCard(item,key,minutes)' in html)
check('Due reminders default to 10 minutes and can be explicitly disabled', 'item.reminderMinutes==null?10:Number(item.reminderMinutes)' in html and 'value="-1"' in html and 'reminderMinutes===-1' in html)
check('Reminder popups support opening or dismissing a specific item', all(token in html for token in ['data-reminder-open=', 'data-reminder-dismiss=', 'data-reminder-close', "if(b.hasAttribute('data-reminder-open'))"]))
check('System notifications remain optional', "canNotifySystem='Notification' in window&&Notification.permission==='granted'" in html)
check('Date-only tasks created after the assumed reminder time are not nagged immediately', 'createdAt>dueAt' in html and 'items created after that assumed time are not immediately nagged' in notes)
check('Reminder de-duplication has an in-memory fallback and a bounded 500-key history', 'state.reminderSentMemory=new Map()' in html and 'new Set([...sent].slice(-500))' in html)
check('Reminder checker runs after event snapshots and on a recurring interval', 'void checkDueReminders(state.user)' in html and 'setInterval(()=>void checkDueReminders(user),30000)' in html)
check('Mobile styles keep confirm dialogs, checklist inputs, and reminders usable', all(token in html for token in ['@media(max-width:760px){.confirm-layer', '.checklist-add-form input{font-size:16px', '.reminder-root{right:10px;left:10px']))
check('Image export limits canvas pixel dimensions for mobile memory', 'const memoryCap=Number(navigator.deviceMemory||0)>0&&Number(navigator.deviceMemory)<=4?4500000:8000000' in html and '4096/logicalW,4096/canvasH' in html)
check('Image export prefers the native file share sheet when supported, with download fallback', 'navigator.canShare({files:[imageFile]})' in html and 'a.download=filename' in html and 'canvas.toBlob' in html)
check('Release notes document device-specific reminder limitations and export behavior', 'does not implement background push delivery when closed' in notes and 'share sheet' in notes)
check('GitHub Actions runs the v1.14.3 release regression suite', 'python tests/test_v1_14_3.py' in workflow)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} v1.14.3 regression checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed))
    sys.exit(1)
