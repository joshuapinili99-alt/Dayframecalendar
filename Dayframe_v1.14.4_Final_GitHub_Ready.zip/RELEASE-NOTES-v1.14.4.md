# Dayframe v1.14.4 Release Notes

## Fixes and improvements

- Registered `storage.rules` in `firebase.json`, so Firebase CLI deployment can publish both Firestore and Storage rules. This addresses the common cause of profile-picture uploads being denied when the bucket/rules are configured in the Console but not the repository deployment.
- Improved profile-picture upload status and actionable Storage error messages, added a robust fallback when a remote avatar URL fails to load, and persisted the Firebase Auth photo URL as a secondary profile hint when available.
- Added a persistent four-item mobile bottom navigation for Calendar, Tasks, Checklist, and Notes. Active-state styling follows the selected view, making Checklists directly reachable with one tap.
- Routed the edit-modal Delete button through the same ID-based deletion handler as list rows, surfaced Firebase deletion failures clearly, and made the sync indicator retry pending writes/deletes when online.
- Kept pending-delete tombstones so stale cloud snapshots and already-open stale editors do not resurrect local deletions before Firebase acknowledges them.
- Updated the service-worker cache version and deployment validation suite.

## Setup requirements

The Firebase Storage bucket must exist, and both Firestore and Storage rules must be published. From the extracted repository root, run `npx firebase-tools login` followed by `npx firebase-tools deploy --only firestore:rules,storage`, or publish each rules file from its corresponding Firebase Console page.

## Verification limits

Automated source and behavior regression tests validate app wiring, rules configuration, deletion queue behavior, stale-editor protection, and package contents. They do not replace live sign-in, Storage upload, Firestore permission, or real Android/iOS device testing against the deployed Firebase project.
