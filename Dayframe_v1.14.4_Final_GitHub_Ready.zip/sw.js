// Dayframe v1.14.4: Storage rules deployment, mobile quick navigation, and resilient profile/delete actions.
const VERSION='1.14.4';
const CACHE=`dayframe-shell-v${VERSION}`;
const SHELL=['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png','./icons/apple-touch-icon.png','./icons/dayframe-logo.svg'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(key=>key.startsWith('dayframe-shell-')&&key!==CACHE).map(key=>caches.delete(key)));
    await self.clients.claim();
    // Newer pages listen for controllerchange and reload once to shed old JavaScript.
    const windows=await self.clients.matchAll({type:'window',includeUncontrolled:true});
    for(const client of windows)client.postMessage({type:'DAYFRAME_UPDATED',version:VERSION});
  })());
});
self.addEventListener('fetch',event=>{
  const req=event.request;
  const url=new URL(req.url);
  if(req.method!=='GET'||url.origin!==self.location.origin)return;
  if(req.mode==='navigate'){
    const scopePath=new URL(self.registration.scope).pathname;
    const isAppEntry=url.pathname===scopePath||url.pathname===scopePath+'index.html'||url.pathname.endsWith('/index.html');
    // no-store prevents a browser HTTP-cache copy of an older index.html from winning.
    event.respondWith(fetch(req,{cache:'no-store'}).then(res=>{
      if(res.ok&&isAppEntry){const copy=res.clone();caches.open(CACHE).then(cache=>cache.put('./index.html',copy))}
      return res;
    }).catch(()=>caches.match('./index.html')));
    return;
  }
  event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(res=>{
    if(res.ok)caches.open(CACHE).then(cache=>cache.put(req,res.clone()));
    return res;
  })));
});
