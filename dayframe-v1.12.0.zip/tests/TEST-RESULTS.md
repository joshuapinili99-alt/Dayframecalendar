# Dayframe v1.12.0 verification

- Static regression checks: 17/17 passed.
- JavaScript module syntax check: passed with Node.js `--check`.
- ZIP integrity: checked when the release archive was created.
- Visual preview images: included for sign-in and calendar at desktop and mobile sizes.

These tests are source/package checks, not proof of a live Firebase deployment. New-account registration, sign-in, rules enforcement, file upload, and real cross-device updates still require Firebase services to be enabled and must be verified against the deployed HTTPS URL.
