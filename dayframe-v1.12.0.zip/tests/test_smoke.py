"""Static regression checks for Dayframe v1.12.0. Live Firebase behavior requires project setup."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
sw = (ROOT / 'sw.js').read_text(encoding='utf-8')
checks = []
def check(name, ok):
    checks.append((name, bool(ok)))

check('Firebase modular SDK modules are imported', all(x in html for x in ['firebase-app.js', 'firebase-auth.js', 'firebase-firestore.js', 'firebase-storage.js']))
check('Provided Firebase project configuration is present', 'my-personal-calendar-a6ef3' in html and 'AIzaSyDb0dsCQnUqPsI266ICPGS4FqLFZeVKLEY' in html)
check('New account flow uses a private Login ID, not a real email input', 'id="auth-login-id"' in html and 'PRIVATE_LOGIN_DOMAIN' in html and 'login.dayframe.invalid' in html)
check('Login ID validation normalizes capitalization and constrains characters', 'normalizeLoginId(value)' in html and 'isValidLoginId(value)' in html and "!id.includes('..')" in html)
check('Legacy email sign-in remains supported', 'Backwards compatibility' in html and 'sendPasswordResetEmail' in html)
check('Firestore persistent cache and multi-tab support are configured', 'persistentLocalCache' in html and 'persistentMultipleTabManager' in html)
check('Planner records and folders use per-user Firestore collections and live listeners', all(x in html for x in ["collection(firebaseDb,'users',uidValue,'events')", "collection(firebaseDb,'users',uidValue,'folders')", 'onSnapshot(']))
check('Theme and background preferences sync through the per-user settings document', "doc(firebaseDb,'users',uidValue,'settings','preferences')" in html and 'startPreferencesListener(user)' in html and 'savePreferencesToCloud()' in html)
check('Firebase Storage uploads profile photos and attachments', all(x in html for x in ['uploadBytes(', 'users/${userId}/profile/avatar', 'users/${userId}/attachments/']))
check('Mobile and desktop share a single responsive application source', all(x in html for x in ['@media(max-width:760px)', '@media(max-width:390px)', 'data-view="Calendar"', 'data-view="Notes"', 'data-view="Meetings"']))
check('Per-user Firestore security rules are included', (ROOT/'firestore.rules').exists() and 'request.auth.uid == userId' in (ROOT/'firestore.rules').read_text())
check('Per-user Storage security rules are included', (ROOT/'storage.rules').exists() and 'request.auth.uid == userId' in (ROOT/'storage.rules').read_text())
check('Firebase and GitHub Pages setup docs are included', (ROOT/'FIREBASE-SETUP.md').exists() and (ROOT/'GITHUB-DEPLOYMENT.md').exists() and 'Authorized domains' in (ROOT/'FIREBASE-SETUP.md').read_text())
check('HTML release marker is current', '<meta name="dayframe-version" content="1.12.0">' in html)
check('Service-worker cache version is current', "const VERSION='1.12.0'" in sw)
check('Supabase code and endpoint references are absent from the app', 'supabase' not in html.lower() and not re.search(r'/rest/v1|/auth/v1|createClient\s*\(', html, re.I))
check('GitHub Actions workflow runs release tests and deploys static assets', '.github/workflows/deploy-pages.yml' and (ROOT/'.github/workflows/deploy-pages.yml').exists() and 'python tests/test_smoke.py' in (ROOT/'.github/workflows/deploy-pages.yml').read_text())

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed))
    sys.exit(1)
