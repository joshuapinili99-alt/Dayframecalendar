# Dayframe release checks

Run `python tests/test_smoke.py` from the project root. The checks validate release markers, Firebase configuration, auth mapping, cross-device data/settings listeners, responsive breakpoints, security-rule presence, and absence of Supabase from the app HTML.

These are static regression checks. They do not prove that Firebase services are enabled or that a live account can sign in; finish `FIREBASE-SETUP.md` and test a deployed HTTPS version on real desktop and mobile devices.
