# Changelog

## v1.12.0
- Replaced the new-account email input with a private Login ID and password.
- Maps Login IDs internally to a non-deliverable Firebase Authentication identifier; no real email is collected for new ID-based accounts.
- Preserves legacy email-based sign-in and password reset.
- Enabled Firestore persistent caching with multi-tab coordination where supported.
- Removed the global cloud write chain so offline writes can be queued independently by Firestore.
- Added synchronized cloud preferences for dark mode and workspace background.
- Updated responsive/mobile documentation, GitHub Pages workflow, service-worker version, and static regression checks.

## v1.11.0
- Connected Firebase Authentication, Firestore planner records, and Firebase Storage uploads.
- Added owner-scoped Firestore and Storage rules and GitHub Pages deployment documentation.
