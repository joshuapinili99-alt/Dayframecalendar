# Dayframe improvement roadmap · v1.12.0

## Delivered in v1.12.0
- Private Login ID + password flow for new accounts without a real email address; existing email-based accounts can still sign in.
- Same responsive HTML codebase for desktop and mobile, using the same Firebase Authentication account and Firestore data paths.
- Firestore live listeners for planner records and folders, plus persistent local caching and offline write queueing.
- Theme and workspace background preferences stored in a per-user Firestore document and synchronized across devices.
- Owner-scoped Firestore and Storage rules, updated GitHub Pages deployment workflow, and automated static checks.

## Recommended next improvements
1. **Account recovery:** ID-only users have no email recovery channel. Add a verified recovery method or a server-side account recovery process before relying on the app for important data.
2. **Conflict handling:** add version fields or a simple conflict banner when two devices edit the same record at once, since a single Firestore document uses last-write-wins behavior.
3. **Attachment lifecycle:** add retry UI for failed uploads and periodic cleanup for orphaned Storage files.
4. **Push reminders:** browser notifications currently require browser support, permission, and the app to be open. Reliable notifications while closed require a push/backend workflow.
5. **Release verification:** test account creation/sign-in, record edit/delete, attachment upload/download, and device-to-device updates on the live Firebase project and on a real iPhone and Android phone.

## Setup dependency

A Firebase config file does not itself turn on project services. Follow `FIREBASE-SETUP.md` to enable Authentication, create Firestore and Storage, publish the security rules, and authorize your HTTPS hostname.
