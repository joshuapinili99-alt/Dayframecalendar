# Dayframe v1.12.0 · Private Login ID + Cross-Device Firebase Sync

Dayframe lets new users create a private **Login ID and password** without entering a real email address. The Login ID is mapped internally to a non-deliverable identifier for Firebase's Email/Password provider. The Firebase Authentication service still protects the password; the app never stores it in local storage. Older accounts made with a real email remain able to sign in using that original email and password.

The same responsive HTML application is used on desktop and mobile. Calendar entries (including tasks, meetings, notes, and checklists), subject folders, profile photos, and file attachments are stored under the same Firebase user account so the same Login ID opens the same planner on each device. Live Firestore listeners update open clients. The selected date/view is intentionally device-local, while dark mode and workspace background preferences are now synchronized to Firebase.

Firestore persistent caching helps queue writes when temporarily offline. Pending changes synchronize when the connection returns. Avoid editing the same record concurrently on multiple devices because updates to an individual document can overwrite one another.

## Before using the app

Complete `FIREBASE-SETUP.md`: enable Email/Password Authentication, create Cloud Firestore and Firebase Storage, publish `firestore.rules` and `storage.rules`, and authorize your HTTPS deployment hostname. Login-ID-only accounts do not have a recovery email and cannot receive password-reset messages, so users must keep their password safe. If that is unacceptable, use an account provider that can verify and recover identities.

## Deploy

Commit the whole project to the root of a GitHub repository, including `.github/workflows/deploy-pages.yml`. In **Settings → Pages**, choose **GitHub Actions**. Then finish the Firebase setup above. The individual `index.html` is a source artifact; for cross-device Firebase use, host it on HTTPS rather than opening it from `file://`.
