# Deploy Dayframe v1.14.0 to GitHub Pages

1. Extract the project ZIP and commit all files, including the hidden `.github/workflows/deploy-pages.yml`, to the repository root.
2. In **Settings → Pages**, choose **GitHub Actions** as the deployment source.
3. In Firebase Console, enable Email/Password Authentication, create Cloud Firestore and Storage, publish `firestore.rules` and `storage.rules`, and authorize your GitHub Pages hostname. See `FIREBASE-SETUP.md`.
4. Open the published HTTPS URL, create a private Login ID, then sign in to the same account on desktop and mobile. Do not create a separate account on the second device.

Example Git commands from the extracted folder:

```bash
git init
git add -A
git commit -m "Deploy Dayframe v1.14.0"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

The single responsive HTML file provides the same features at desktop and mobile breakpoints. Planner records and folders sync through Firestore; profile photos and attachments use Firebase Storage; theme and workspace background preferences sync through a per-user Firestore settings document. Current date, view mode, and some browser notification state remain device-specific by design.


## Recovering desktop items that were not previously uploaded

After deploying v1.14.0, sign in on the original desktop browser using the same Login ID as mobile. Dayframe merges the freshest local cache with cloud records and attempts to upload local-only/newer records. Keep the app online until the sync status returns to up-to-date. Then refresh mobile. A successful recovery requires the same Firebase account and valid Firestore rules.
