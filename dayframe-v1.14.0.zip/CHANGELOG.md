# Dayframe Changelog

## v1.14.0 · Cross-device sync recovery

- Fixed startup reconciliation that could ignore desktop-local tasks when some cloud records already existed.
- Merges local cache and Firestore records by ID and timestamps, uploads local-only/newer local records, and preserves newer cloud records.
- Live Firestore listeners preserve pending local edits and deletions instead of allowing an older snapshot to hide them.
- Failed cloud writes remain locally available and retry on reconnection or when the app becomes visible.
- Selects the freshest complete browser cache snapshot to avoid restoring stale IndexedDB data after a deletion.
- The sync-status message helps identify which Login ID is active, so desktop and mobile accounts can be compared.
- Adds automated regression tests for partial-cloud recovery and reconciliation behavior.

## v1.13.0 · Performance and mobile UX

- Faster calendar first paint and grouped event-by-date rendering.
- Mobile layout hardening across calendar, tasks, meetings, checklists, folders, notes, attachments, details, and forms.
- Disabled mobile pinch/double-tap zoom as requested while preserving normal scrolling and taps.
- Added high-resolution PNG export for Month, Week, and Agenda calendar views.
- Added a consistent Dayframe logo, refreshed app icons, favicon, and service-worker cache.

## v1.12.0 · Private Login ID

- Added a private Login ID and password flow for new users while retaining legacy email-based sign-in.
- Enabled persistent Firestore caching and multi-tab coordination where supported.
- Added synchronized dark-mode and workspace-background preferences.

## v1.11.0 · Firebase integration

- Connected Firebase Authentication, Cloud Firestore planner records, and Firebase Storage uploads.
- Added owner-scoped Firestore and Storage security rules and GitHub Pages deployment documentation.
