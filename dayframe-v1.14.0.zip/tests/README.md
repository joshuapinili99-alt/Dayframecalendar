# Dayframe release checks

From the project root, run:

```bash
python tests/test_smoke.py
python tests/test_sync_reconcile.py
python tests/check_js_syntax.py
```

The checks validate the release marker, Firebase configuration, Login ID mapping, Firestore listeners, responsive breakpoints, security-rule presence, Supabase removal, local/cloud reconciliation, protection of pending local writes, and retry behavior.

Static checks and simulated reconciliation tests do not prove that Firebase services are enabled or that a live account can sign in. Finish `FIREBASE-SETUP.md`, deploy to HTTPS, and test on desktop and mobile using the exact same Login ID.
