"""Static regression checks for Dayframe v1.14.0. Live Firebase behavior requires project setup."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
sw = (ROOT / 'sw.js').read_text(encoding='utf-8')
checks = []
def check(name, ok):
    checks.append((name, bool(ok)))

check('Firebase modular SDK modules are imported', all(x in html for x in ['firebase-app.js', 'firebase-auth.js', 'firebase-firestore.js', 'firebase-storage.js']))
check('Provided Firebase project configuration is present', 'my-personal-calendar-a6ef3' in html and 'AIzaSyDb0dsCQnUqPsI266ICPGS4FqLFZeVKLEY' in html)
check('New account flow uses a private Login ID, not a real email input', 'id="auth-login-id"' in html and 'PRIVATE_LOGIN_DOMAIN' in html and 'login.dayframe.invalid' in html)
check('Login ID validation normalizes capitalization and constrains characters', 'normalizeLoginId(value)' in html and 'isValidLoginId(value)' in html and "!id.includes('..')" in html)
check('Legacy email sign-in remains supported', 'Backwards compatibility' in html and 'sendPasswordResetEmail' in html)
check('Firestore persistent cache and multi-tab support are configured', 'persistentLocalCache' in html and 'persistentMultipleTabManager' in html)
check('Planner records and folders use per-user Firestore collections and live listeners', all(x in html for x in ["collection(firebaseDb,'users',uidValue,'events')", "collection(firebaseDb,'users',uidValue,'folders')", 'onSnapshot(']))
check('Theme and background preferences sync through the per-user settings document', "doc(firebaseDb,'users',uidValue,'settings','preferences')" in html and 'startPreferencesListener(user)' in html and 'savePreferencesToCloud()' in html)
check('Firebase Storage uploads profile photos and attachments', all(x in html for x in ['uploadBytes(', 'users/${userId}/profile/avatar', 'users/${userId}/attachments/']))
check('Mobile and desktop share a single responsive application source', all(x in html for x in ['@media(max-width:760px)', '@media(max-width:390px)', 'data-view="Calendar"', 'data-view="Notes"', 'data-view="Meetings"']))
check('Per-user Firestore security rules are included', (ROOT/'firestore.rules').exists() and 'request.auth.uid == userId' in (ROOT/'firestore.rules').read_text())
check('Per-user Storage security rules are included', (ROOT/'storage.rules').exists() and 'request.auth.uid == userId' in (ROOT/'storage.rules').read_text())
check('Firebase and GitHub Pages setup docs are included', (ROOT/'FIREBASE-SETUP.md').exists() and (ROOT/'GITHUB-DEPLOYMENT.md').exists() and 'Authorized domains' in (ROOT/'FIREBASE-SETUP.md').read_text())
check('HTML release marker is current', '<meta name="dayframe-version" content="1.14.0">' in html)

check('Calendar is rendered from local cache before Firebase reads complete', 'Render the per-user cache before any network await' in html)
check('Calendar renderer groups events by date for lower rendering cost', 'eventsByDate=new Map()' in html and 'hoverCard(c.key,items)' in html)
check('Calendar can be exported as a PNG image', 'id="calendar-export-image"' in html and 'function exportCalendarAsImage()' in html and "canvas.toBlob" in html)
check('Mobile interface zoom is disabled', 'maximum-scale=1,user-scalable=no' in html and "'gesturestart','gesturechange','gestureend'" in html)
check('Shared workspace no longer uses scaling transforms', "ws.classList.remove('view-calendar-scale','view-large-scale')" in html and 'transform:scale(.8)' not in html and 'width:125%' not in html)
check('Dayframe logo and refreshed PWA icon files exist', (ROOT/'icons/dayframe-logo.svg').exists() and (ROOT/'icons/icon-192.png').exists() and 'dayframe-logo.svg' in html)
check('Mobile overlap hardening rules are included', '.folder-card{display:flex;flex-wrap:wrap' in html and '.modal-body{display:grid;grid-template-columns:minmax(0,1fr)' in html)

check('Service-worker cache version is current', "const VERSION='1.14.0'" in sw)
check('Supabase code and endpoint references are absent from the app', 'supabase' not in html.lower() and not re.search(r'/rest/v1|/auth/v1|createClient\s*\(', html, re.I))
check('GitHub Actions workflow runs release tests and deploys static assets', '.github/workflows/deploy-pages.yml' and (ROOT/'.github/workflows/deploy-pages.yml').exists() and 'python tests/test_smoke.py' in (ROOT/'.github/workflows/deploy-pages.yml').read_text())

check('Desktop-only local records are reconciled with partial cloud data', 'function reconcileCloudItems(remoteItems,localItems)' in html and 'const eventsResult=reconcileCloudItems(cloudEvents,localEvents)' in html and 'const foldersResult=reconcileCloudItems(cloudFolders,localFolders)' in html)
check('Local-only and newer local records are submitted to Firebase on startup', "queueCloudRecoveryWrites('events',eventsResult.toUpload)" in html and "queueCloudRecoveryWrites('folders',foldersResult.toUpload)" in html)
check('Live Firestore snapshots reconcile and preserve pending local edits/deletes', 'function mergeCloudWithPending(remoteItems,collectionName)' in html and "mergeCloudWithPending(reconciled.items,'events')" in html and "mergeCloudWithPending(reconciled.items,'folders')" in html and "queueCloudRecoveryWrites('events',reconciled.toUpload)" in html)
check('Initial cloud read failure keeps the local planner visible instead of signing out', 'Initial Firestore load failed; keeping the local planner visible.' in html and 'Your local planner copy remains visible.' in html and 'startCloudListeners(user);startDueReminderChecker(user);' in html)
check('Failed cloud mutations remain locally pending and retry on reconnection', 'state.cloudRecovery={events:new Map(),folders:new Map()}' in html and 'function retryPendingCloudRecovery' in html and 'retryPendingCloudRecovery(state.user)' in html)
check('Freshest browser cache snapshot is selected rather than blindly unioning stale cache copies', "candidates.sort((a,b)=>recordTimestamp({updatedAt:b.data.updatedAt})-recordTimestamp({updatedAt:a.data.updatedAt}))" in html and 'older IndexedDB snapshot cannot re-introduce deleted records' in html)
check('Account identity helper explains that devices must use the same Login ID', 'Current account: ${id}' in html and 'same Firebase Login ID' in html)
check('Mobile sync status is visible and tappable for account troubleshooting', 'id="sync-status" class="sync-status" type="button"' in html and '.sync-status{display:inline-flex!important' in html and 'aria-label="Planner sync status"' in html)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed))
    sys.exit(1)
