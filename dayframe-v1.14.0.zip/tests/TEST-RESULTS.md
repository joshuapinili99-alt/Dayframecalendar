# Dayframe v1.14.0 verification

- Static regression checks: 32/32 passed.
- Sync reconciliation behavior test: passed. Verifies local-only tasks/folders, newer local edits, newer cloud records, legacy records without update timestamps, and pending edits/deletes.
- JavaScript module syntax check: passed with Node.js `--check`.
- ZIP integrity: checked when the release archive is created.

These checks exercise source-level reconciliation and package integrity. They do not prove that Firebase is enabled or that live device-to-device sync works on your Firebase project; test on the published HTTPS site using the same Login ID on both devices.
