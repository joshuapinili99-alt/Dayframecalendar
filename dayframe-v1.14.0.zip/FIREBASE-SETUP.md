# Dayframe Firebase setup (v1.14.0)

The web configuration from `dayframe.txt` is included in `index.html`. Dayframe provides a private Login ID and password interface for new accounts, while Firebase Authentication handles the credential securely.

## One-time Firebase Console setup

1. Open the Firebase project `my-personal-calendar-a6ef3`.
2. In **Authentication → Sign-in method**, enable **Email/Password**. Dayframe maps a new Login ID to an internal, non-deliverable address under `login.dayframe.invalid`, since the Firebase Web password provider expects an email/password credential. Users do not have to provide or verify a real email address.
3. In **Firestore Database**, create a database. Choose a location and use locked/production mode.
4. In **Storage**, enable Cloud Storage and create the default bucket if it is not already enabled.
5. Publish `firestore.rules` from **Firestore Database → Rules**.
6. Publish `storage.rules` from **Storage → Rules**. These rules limit access to each signed-in user's own UID path. Do not use public read/write rules.
7. In **Authentication → Settings → Authorized domains**, add your GitHub Pages hostname (for example, `your-username.github.io`, without `https://` or a path) and any custom domain.

## Login ID behavior

- New Login IDs must be 3-24 characters, using letters, numbers, periods, underscores, or hyphens. IDs are case-insensitive, cannot start or end with punctuation, and cannot contain two consecutive periods.
- Use the same Login ID and password on every device. It resolves to the same Firebase UID, so planner data is shared through Firestore. Do not create a separate account on your phone.
- The app does not collect real email addresses for new Login ID accounts. Since there is no recovery email, those accounts cannot use email password reset. Keep the password in a password manager.
- Accounts created with a real email in earlier versions remain accessible by entering that original email and password in the Login ID field. Those older accounts can still use email-based password reset.

## Cloud data and sync

- Planner theme and workspace background preferences are stored in `users/{uid}/settings/preferences` so these choices follow the account across devices.
- The current calendar date/view, selected notes panel state, and notification-dismissal history remain local to each device, which avoids unexpectedly changing the other device's viewport or duplicate notification state.

- `users/{uid}/events/{eventId}` in Firestore (tasks, meetings, notes, checklists, calendar records)
- `users/{uid}/folders/{folderId}` in Firestore
- `users/{uid}/settings/preferences` in Firestore
- `users/{uid}/profile/avatar` in Firebase Storage
- `users/{uid}/attachments/{fileName}` in Firebase Storage

The HTML imports Firebase's modular SDK from `gstatic.com`. It configures Firestore persistent local caching with multi-tab coordination where supported. Offline writes are queued locally by Firestore and sent when the device reconnects. Mobile and desktop use the same responsive HTML, auth account, Firestore paths, and feature handlers. UI preferences such as theme, selected view, and current date are device-local.

## Deploy to GitHub Pages

1. Extract the ZIP and commit its contents, including `.github/workflows/deploy-pages.yml`, to the repository root.
2. In **Settings → Pages**, choose **GitHub Actions** as the source.
3. Complete the Firebase steps above.
4. Open the deployed HTTPS URL, create a Login ID, then use that same ID and password on all devices.

The Firebase web API key identifies the project; it is not an admin/service-account key. Security depends on Authentication and publishing the owner-only rules. Live sign-in and cloud sync still need to be tested against the actual enabled Firebase services.
