# Dayframe v1.14.0 · Private Login ID + Cross-Device Firebase Sync

Dayframe lets new users create a private **Login ID and password** without entering a real email address. The Login ID is mapped internally to a non-deliverable identifier for Firebase's Email/Password provider. The Firebase Authentication service still protects the password; the app never stores it in local storage. Older accounts made with a real email remain able to sign in using that original email and password.

The same responsive HTML application is used on desktop and mobile. Calendar entries (including tasks, meetings, notes, and checklists), subject folders, profile photos, and file attachments are stored under the same Firebase user account so the same Login ID opens the same planner on each device. Live Firestore listeners update open clients. The selected date/view is intentionally device-local, while dark mode and workspace background preferences are now synchronized to Firebase.

Firestore persistent caching helps queue writes when temporarily offline. Pending changes synchronize when the connection returns. Avoid editing the same record concurrently on multiple devices because updates to an individual document can overwrite one another.

## Before using the app

Complete `FIREBASE-SETUP.md`: enable Email/Password Authentication, create Cloud Firestore and Firebase Storage, publish `firestore.rules` and `storage.rules`, and authorize your HTTPS deployment hostname. Login-ID-only accounts do not have a recovery email and cannot receive password-reset messages, so users must keep their password safe. If that is unacceptable, use an account provider that can verify and recover identities.

## Deploy

Commit the whole project to the root of a GitHub repository, including `.github/workflows/deploy-pages.yml`. In **Settings → Pages**, choose **GitHub Actions**. Then finish the Firebase setup above. The individual `index.html` is a source artifact; for cross-device Firebase use, host it on HTTPS rather than opening it from `file://`.

## Existing app features

- The calendar renders from the local account cache while Firebase refreshes in the background.
- Calendar items are grouped by date to reduce repeat work for month and week views.
- Responsive layout rules cover calendar, tasks, meetings, checklists, notes, folders, attachments, and modal forms.
- Calendar views can be exported as a high-resolution PNG.
- Dayframe branding is used in the app, favicon, and installable app icons.

## v1.14.0 cross-device sync recovery

On sign-in, Dayframe reconciles the freshest browser cache with the Firebase events and folders collections. Local-only records and records with newer local `updatedAt` timestamps are submitted to Firestore instead of being discarded when the cloud already contains other records. Live listeners preserve local changes while writes are pending. Failed writes remain visible locally and are retried when connectivity returns or the app becomes visible again. The compact sync button is available on mobile and desktop; tap it to compare the active Login ID and short account reference.

To recover older desktop-only items, deploy this version, open it on the original desktop browser, sign in with the exact same Login ID used on mobile, and keep it online until the sync status indicates that pending items have cleared. Then refresh Dayframe on mobile. If permissions are misconfigured or the devices use different Firebase accounts, the items will not appear on both devices; check the on-screen sync error and Firebase Console.

See `previews/dayframe-v1.14.0-preview.png` for an illustrative layout preview (sample items, not user data). For device recovery steps, see `CROSS-DEVICE-RECOVERY.md`.
