# Existing cloud data note

This release uses Supabase as its only remote backend. Switching a web application backend does not automatically transfer prior user accounts or cloud records.

The app can recover entries that remain in the browser's previous local cache, but records stored only in an earlier cloud project must be exported and imported separately. Before importing, verify the destination Supabase user ID for each account. Never put a service-role/secret API key in the browser or use the public client key for administrative exports.
