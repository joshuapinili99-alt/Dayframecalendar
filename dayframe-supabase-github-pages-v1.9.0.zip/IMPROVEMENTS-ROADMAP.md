# Dayframe improvement roadmap

## Recommended next upgrades

1. **Conflict handling**: detect when two devices edit the same item and offer Keep mine / Use latest / Compare.
2. **Export and restore**: provide user-controlled JSON/CSV export and a validated import workflow.
3. **Recurring tasks and reminders**: recurrence rules, notification preferences, timezone-aware reminders, and calendar integration.
4. **Attachment management**: upload progress, cancel/retry controls, previews, retention policies, and clearer file limits.
5. **Accessibility**: full keyboard navigation, visible focus, screen-reader labels, reduced-motion support, and contrast checks.
6. **Performance monitoring**: track slow save requests and errors without collecting note contents or other sensitive planner data.
7. **Device testing**: test Safari on iPhone and Chrome on Android, including installable PWA behavior, sleep/resume, airplane mode, poor networks, and storage pressure.

## Current cross-device model

Dayframe v1.8.0 uses Supabase Realtime for fast database change notifications, with a 12-second database refresh fallback while the page is open and active. It discards stale cloud reads that overlap a newer local mutation. Pending local writes are stored in localStorage plus IndexedDB and are retried after reconnecting. For production, verify the three required tables are in the `supabase_realtime` publication and test two physical devices signed in to the same account.

## Important limits

Automated smoke tests help find regressions but cannot prove that an app is 100% bug-free. Before real use, validate the live Supabase SQL, RLS rules, Auth redirects, storage permissions, data saves, profile photo changes, and cross-device updates on actual devices.
