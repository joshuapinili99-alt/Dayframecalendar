(() => {
  const originalSetTimeout = window.setTimeout.bind(window);
  try {
    const memory = new Map();
    const localStore = {
      getItem: k => memory.has(k) ? memory.get(k) : null,
      setItem: (k, v) => {
        if (window.__mockDayframe?.failLocalStorage) throw new DOMException('Simulated localStorage quota/block', 'QuotaExceededError');
        memory.set(k, String(v));
      },
      removeItem: k => memory.delete(k),
      clear: () => memory.clear()
    };
    Object.defineProperty(window, 'localStorage', { configurable: true, value: localStore });
  } catch (_) {}

  const user = { id: '11111111-1111-4111-8111-111111111111', email: 'taylor@example.com', user_metadata: { display_name: 'Taylor Demo', full_name: 'Taylor Demo' } };
  const tables = {
    dayframe_events: new Map(),
    dayframe_folders: new Map(),
    dayframe_profiles: new Map()
  };
  const storageObjects = new Map();
  const listeners = [];
  const channels = new Set();
  let currentUser = user;
  let failProfileOnce = false;
  let failNextEventsOnce = false;
  let failUploadOnce = false;
  let disableRealtime = false;
  let delayNextSelectOnce = false;

  const indexedRecords = new Map();
  let recordsCreated = false;
  const fakeIndexedDB = {
    open() {
      const req = {};
      originalSetTimeout(() => {
        req.result = {
          objectStoreNames: { contains(name) { return recordsCreated && name === 'records'; } },
          createObjectStore(name) { recordsCreated = name === 'records'; return {}; },
          transaction() {
            const tx = {};
            const store = {
              put(record) { indexedRecords.set(record.key, { ...record }); originalSetTimeout(() => tx.oncomplete?.(), 0); return {}; },
              get(key) { const r = {}; originalSetTimeout(() => { r.result = indexedRecords.get(key); r.onsuccess?.(); }, 0); return r; },
              delete(key) { indexedRecords.delete(key); originalSetTimeout(() => tx.oncomplete?.(), 0); return {}; }
            };
            tx.objectStore = () => store;
            return tx;
          }
        };
        req.onupgradeneeded?.(); req.onsuccess?.();
      }, 0);
      return req;
    }
  };
  try { Object.defineProperty(window, 'indexedDB', { configurable: true, value: fakeIndexedDB }); } catch (_) { window.indexedDB = fakeIndexedDB; }

  function fireAuth(event, nextUser = currentUser) { for (const cb of [...listeners]) cb(event, nextUser ? { user: { ...nextUser } } : null); }
  const auth = {
    onAuthStateChange(cb) { listeners.push(cb); originalSetTimeout(() => cb('INITIAL_SESSION', currentUser ? { user: { ...currentUser } } : null), 10); return { data: { subscription: { unsubscribe() { const i = listeners.indexOf(cb); if (i >= 0) listeners.splice(i, 1); } } } }; },
    async signInWithPassword({ email }) { currentUser = { ...user, email }; fireAuth('SIGNED_IN', currentUser); return { data: { user: currentUser, session: { user: currentUser } }, error: null }; },
    async signUp({ email, options }) { currentUser = { ...user, email, user_metadata: options?.data || {} }; fireAuth('SIGNED_IN', currentUser); return { data: { user: currentUser, session: { user: currentUser } }, error: null }; },
    async signInWithOAuth() { return { data: {}, error: null }; },
    async resetPasswordForEmail() { return { data: {}, error: null }; },
    async updateUser({ data }) { currentUser = { ...currentUser, user_metadata: { ...(currentUser?.user_metadata || {}), ...data } }; fireAuth('USER_UPDATED', currentUser); return { data: { user: currentUser }, error: null }; },
    async signOut() { currentUser = null; fireAuth('SIGNED_OUT', null); return { error: null }; }
  };

  function rowKey(table, row) { return table === 'dayframe_profiles' ? row.user_id : `${row.user_id}/${row.id}`; }
  function notifyTable(table) { for (const ch of channels) for (const handler of ch.handlers) if (handler.table === table) handler.callback({ schema: 'public', table, eventType: 'mock' }); }
  function makeQuery(table) {
    const q = { table, action: 'select', payload: null, filters: [], columns: '*', conflict: null };
    q.select = columns => { q.action = 'select'; q.columns = columns; return q; };
    q.eq = (key, value) => { q.filters.push([key, value]); return q; };
    q.maybeSingle = async () => { const result = await q.execute(); return { data: result.data?.[0] || null, error: result.error || null }; };
    q.upsert = (payload, options = {}) => { q.action = 'upsert'; q.payload = payload; q.conflict = options.onConflict; return q; };
    q.delete = () => { q.action = 'delete'; return q; };
    q.update = payload => { q.action = 'update'; q.payload = payload; return q; };
    q.execute = async () => {
      if (table === 'dayframe_profiles' && q.action === 'upsert' && failProfileOnce) { failProfileOnce = false; return { data: null, error: { code: '42501', message: 'Simulated RLS denial', status: 403 } }; }
      if (table === 'dayframe_events' && q.action === 'upsert' && q.payload?.data?.title === 'Recovery test' && failNextEventsOnce) { failNextEventsOnce = false; return { data: null, error: { code: 'PGRST000', message: 'Simulated temporary network interruption', status: 503 } }; }
      const store = tables[table];
      if (!store) return { data: null, error: { message: 'Unknown test table: ' + table, code: '42P01', status: 404 } };
      const matches = row => q.filters.every(([k, v]) => row[k] === v);
      if (q.action === 'select') {
        const snapshot = [...store.values()].filter(matches).map(r => ({ ...r }));
        if (delayNextSelectOnce) {
          delayNextSelectOnce = false;
          await new Promise(resolve => originalSetTimeout(resolve, 280));
          return { data: snapshot, error: null };
        }
        return { data: snapshot, error: null };
      }
      if (q.action === 'upsert') { const row = { ...q.payload }; store.set(rowKey(table, row), row); notifyTable(table); return { data: row, error: null }; }
      if (q.action === 'delete') { for (const [key, row] of [...store.entries()]) if (matches(row)) store.delete(key); notifyTable(table); return { data: null, error: null }; }
      if (q.action === 'update') { for (const [key, row] of [...store.entries()]) if (matches(row)) store.set(key, { ...row, ...q.payload }); notifyTable(table); return { data: null, error: null }; }
      return { data: null, error: { message: 'Unsupported test query action' } };
    };
    q.then = (resolve, reject) => q.execute().then(resolve, reject);
    return q;
  }

  const storageApi = {
    from(bucket) { return {
      async upload(path, file, options) { if (failUploadOnce) { failUploadOnce = false; return { data: null, error: { message: 'Simulated Storage upload failure', status: 503 } }; } storageObjects.set(`${bucket}/${path}`, { file, options }); return { data: { path }, error: null }; },
      async createSignedUrl(path, expiry) { return { data: { signedUrl: `https://mock-supabase.invalid/${encodeURIComponent(path)}?expires=${expiry}` }, error: null }; },
      async remove(paths) { for (const path of paths) storageObjects.delete(`${bucket}/${path}`); return { data: [], error: null }; }
    }; }
  };
  const client = {
    auth,
    from: makeQuery,
    storage: storageApi,
    channel(name) { const ch = { name, handlers: [], on(_type, filter, callback) { ch.handlers.push({ table: filter.table, callback }); return ch; }, subscribe(callback) { if (!disableRealtime) { channels.add(ch); originalSetTimeout(() => callback?.('SUBSCRIBED'), 5); } else { originalSetTimeout(() => callback?.('CHANNEL_ERROR', new Error('Simulated realtime disabled')), 5); } return ch; } }; return ch; },
    async removeChannel(ch) { channels.delete(ch); return 'ok'; }
  };
  window.__mockDayframe = {
    client, tables, storageObjects, indexedRecords, user,
    get failProfileOnce() { return failProfileOnce; }, set failProfileOnce(v) { failProfileOnce = v; },
    get failNextEventsOnce() { return failNextEventsOnce; }, set failNextEventsOnce(v) { failNextEventsOnce = v; },
    get failUploadOnce() { return failUploadOnce; }, set failUploadOnce(v) { failUploadOnce = v; },
    get disableRealtime() { return disableRealtime; }, set disableRealtime(v) { disableRealtime = Boolean(v); if (disableRealtime) channels.clear(); },
    get delayNextSelectOnce() { return delayNextSelectOnce; }, set delayNextSelectOnce(v) { delayNextSelectOnce = Boolean(v); },
    failLocalStorage: false,
    injectEvent(data) { const row = { user_id: user.id, id: data.id, data, updated_at: data.updatedAt || new Date().toISOString() }; tables.dayframe_events.set(rowKey('dayframe_events', row), row); notifyTable('dayframe_events'); },
    get data() { return { events: tables.dayframe_events, folders: tables.dayframe_folders, profiles: tables.dayframe_profiles }; }
  };
  window.supabase = { createClient(url, key, options) { window.__mockDayframe.clientOptions = { url, key, options }; return client; } };
})();
