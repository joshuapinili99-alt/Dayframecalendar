# Dayframe v1.9.0

- Calendar view uses 80% workspace scale; all other navigation views use 110%, with width compensation for responsive layouts.
- Fixed return-to-tab refresh by listening on `document.visibilitychange` and `pageshow`; also starts the due-reminder checker when a session is restored.
- Added per-item due-date reminder options (due time, 10 min, 1 hour, 1 day) using browser notifications while Dayframe is open and active.
- Rebuilt Notes into a searchable, pinned notes list plus distraction-free editor, with mobile list/editor navigation and debounced autosaving.
- Preserved unsaved note drafts over in-flight cloud reads, and discard stale read snapshots when a cloud write completes.
- Fixed the collapsed details pane so its padding cannot leave a narrow overlay on desktop. Updated service-worker shell version to force refresh of the current app after redeployment.
- Added tests for view scales, note creation/search/autosave/pinning, reminder options, and notification opt-in.
