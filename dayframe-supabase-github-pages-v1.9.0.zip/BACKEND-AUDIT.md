# Dayframe v1.8.0 backend audit

- Remote authentication: Supabase Auth only.
- Planner records and checklist items: Supabase Postgres table `public.dayframe_events`, JSONB column `data`.
- Folder records: `public.dayframe_folders`, JSONB column `data`.
- Profile photo: `public.dayframe_profiles.avatar_data_url`.
- Attachments: private Supabase Storage bucket `dayframe-attachments`.
- Cross-device updates: Supabase Realtime plus database readback fallback.
- Browser IndexedDB/localStorage: only cache, device preferences, and offline recovery/pending operations. They are not alternate cloud backends.
- The active app and deploy ZIP contain no legacy backend SDK, config, or service calls.

Important distinction: packaging a Supabase-only app does not delete a separate older cloud project or transfer data from it. Any existing records in a previous cloud project must be exported/imported separately if needed.
