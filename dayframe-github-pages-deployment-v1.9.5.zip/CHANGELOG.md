# Changelog

## v1.9.5
- Standardized the backend on the single Supabase table `public.dayframe`.
- Added `record_type` separation for events, folders, and profile photos while retaining existing planner features.
- Updated reads, writes, delete filters, profile-photo syncing, and Realtime subscriptions to target `public.dayframe`.
- Updated setup and repair SQL to secure the single table and migrate data from older Dayframe tables without deleting them.
- Bumped the service-worker cache version, requests fresh navigation HTML, and prompts open pages to reload after a controller update.
- Added a GitHub Actions release guard that blocks deployment if the repository root still contains the old split-table runtime.

## v1.9.3
- Improved Supabase schema-cache diagnostics and cross-device sync reliability.
- Added targeted repair guidance for missing database tables and schema cache.
