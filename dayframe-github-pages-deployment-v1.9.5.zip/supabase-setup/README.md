# Dayframe Supabase setup · v1.9.5

## 1. Create and secure the Dayframe table

1. Open the Supabase project at `https://nkbifjskftalbmorzend.supabase.co`.
2. Go to **SQL Editor → New query**.
3. Paste the contents of `setup.sql` and run it as the project owner.
4. Confirm that `public.dayframe` exists and that the `dayframe-attachments` Storage bucket is **private**.
5. Check the final verification query. If Realtime is enabled, it should list `public.dayframe` in `supabase_realtime`.

The app uses one Postgres table, `public.dayframe`, with `record_type` values `event`, `folder`, and `profile`. Row Level Security (RLS) restricts every row to its owning authenticated user. The SQL also migrates data from the legacy `dayframe_events`, `dayframe_folders`, and `dayframe_profiles` tables if those exist. It does not delete the legacy tables.

The SQL revokes direct table access from `PUBLIC` and `anon`, then grants access to authenticated users through RLS. Do not disable RLS or add a service-role key to the HTML. If this Supabase project already serves other apps, review existing grants and policies before running it: pre-existing permissive policies can still allow access because permissive policies combine with OR.

If `public.dayframe` is not listed for Realtime, open **Database → Replication / Publications** or **Integrations → Realtime** in Supabase Dashboard and enable it. The app also refreshes every 12 seconds while open and active as a fallback.

## 2. Configure email/password auth

In **Authentication → Sign In / Providers**, enable Email. Decide whether to require email confirmation. If it is enabled, new users must confirm their email before signing in.

In **Authentication → URL Configuration**, set the Site URL to the deployed page. Add the exact GitHub Pages/Netlify URL to Redirect URLs. For a GitHub Pages project site, include the full repo path, for example `https://USERNAME.github.io/REPOSITORY/`.

## 3. Optional Google sign-in

Enable Google under **Authentication → Sign In / Providers** and add the Supabase callback URL shown in its settings to your Google OAuth client. Also include the deployed Dayframe URL in Supabase Redirect URLs.

## 4. Data persistence

Calendar items, tasks, meetings, notes, checklists, folders, and profile photos are stored in `public.dayframe`. Planner and folder JSONB content is stored in `data`; the `record_type` column identifies `event`, `folder`, or `profile`; profile photos use `avatar_data_url`. Attachments use the private `dayframe-attachments` Storage bucket. The app retains local recovery data in browser storage and queues unsaved changes when network requests fail.

## 5. Key safety

The embedded key is the Supabase `anon`/public client key. Browsers can read it by design. Its safety depends on RLS and Storage policies. Never place a `service_role` or secret API key in this static website.

## 6. Troubleshooting missing table / schema cache

For `Could not find the table 'public.dayframe' in the schema cache`, run `setup.sql` in this project. It creates/configures the expected single table, migrates legacy rows if present, and sends `NOTIFY pgrst, 'reload schema'`. The same repair is available as `FIX-DAYFRAME-SCHEMA-CACHE.sql`. If the table exists but is still not found, check **Project Settings → API → Exposed schemas** includes `public`, wait a few seconds, hard-refresh the site, and confirm the Supabase project URL matches the one embedded in `index.html`.

## 7. Previous cloud data

Supabase accounts and cloud data are separate from a previous cloud provider. This application can recover planner items retained in the local browser cache, but it does not automatically migrate records/accounts stored only in a different cloud project. Export/import those records separately after mapping each former account to its verified Supabase user.
