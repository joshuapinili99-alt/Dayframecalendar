# Dayframe backend audit · v1.9.5

- Database table: `public.dayframe`.
- Row types: `event`, `folder`, and `profile`, distinguished by `record_type`.
- Planner and folder records: JSONB column `data`.
- Profile photo: `avatar_data_url` on the user's `profile` row.
- Attachments: private Supabase Storage bucket `dayframe-attachments` with owner-scoped paths and signed download URLs.
- Access control: Row Level Security checks `auth.uid() = user_id`; anonymous/public table privileges are revoked.
- Cross-device sync: Realtime on `public.dayframe`, plus a 12-second active-page refresh fallback.
- Legacy compatibility: setup SQL copies data from `public.dayframe_events`, `public.dayframe_folders`, and `public.dayframe_profiles` if these older tables exist; it does not delete them.
