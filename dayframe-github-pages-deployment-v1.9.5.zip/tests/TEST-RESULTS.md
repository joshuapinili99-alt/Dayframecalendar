# Dayframe v1.9.5 test results

**Result: 54/54 automated browser smoke checks passed** on the current package source.

The suite uses a simulated Supabase API; it does not connect to or modify the live Supabase project. It verifies the v1.9.5 version marker, single-table `public.dayframe` runtime, absence of direct requests to the legacy split tables, service-worker update behavior, saving, Notes autosave, profile photos, attachments, checklists, reminders, recovery from simulated network errors, desktop/mobile layout, and absence of page-level JavaScript runtime errors.

Run: `python tests/test_smoke.py` with Playwright and Chromium installed.
