# Fix: `public.dayframe_events` is still being requested

This error means the website is serving the old v1.9.3 app code, which requests separate tables such as `public.dayframe_events`. The v1.9.5 runtime uses the single `public.dayframe` table. Running SQL alone will not replace the old JavaScript.

## Deploy the correct files

1. Extract this ZIP.
2. In the GitHub repository, replace the root `index.html` and `sw.js` with the files in this package. Ensure you are editing the repository root, not uploading a nested `dayframe-v1.9.5/` folder.
3. Commit to the `main` branch.
4. In GitHub **Actions**, confirm `Deploy Dayframe to GitHub Pages` succeeds. If it did not run, confirm **Settings → Pages → Build and deployment → GitHub Actions**.
5. Open the deployment URL shown by the completed workflow and hard-refresh with **Ctrl+Shift+R**. Testing in a private/incognito window is a quick way to rule out an old tab or local page state.
6. Verify the delivered page source contains `<meta name="dayframe-version" content="1.9.5">`.

The v1.9.5 service worker has a new cache version, removes the older Dayframe shell cache, requests the latest entry page without using the browser HTTP cache, and updates an open page after a controller change.

## Only if the new error says `public.dayframe`

If the message names `public.dayframe` (not `public.dayframe_events`), run `supabase-setup/setup.sql` in the SQL Editor of the exact Supabase project embedded in `index.html`, then reload the page.
