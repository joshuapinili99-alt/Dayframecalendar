# Dayframe v1.15.1 · Connected Notes Folders and Reliable Image Paste

Dayframe lets new users create a private **Login ID and password** without entering a real email address. The Login ID is mapped internally to a non-deliverable identifier for Firebase's Email/Password provider. The Firebase Authentication service still protects the password; the app never stores it in local storage. Older accounts made with a real email remain able to sign in using that original email and password.

The same responsive HTML application is used on desktop and mobile. Phones open directly into the Tasks list so all open tasks across dates are visible in readable rows. The Calendar view opens to a readable 14-day Agenda on phones instead of squeezing the month grid. Changes save to the local account cache immediately, then sync to Firebase in the background without blocking the interface or showing routine success popups. Calendar entries (including tasks, meetings, notes, and checklists), subject folders, profile photos, and file attachments are stored under the same Firebase user account so the same Login ID opens the same planner on each device. Live Firestore listeners update open clients. The selected date/view is intentionally device-local, while dark mode and workspace background preferences are now synchronized to Firebase.

Firestore persistent caching helps queue writes when temporarily offline. Pending changes synchronize when the connection returns. Avoid editing the same record concurrently on multiple devices because updates to an individual document can overwrite one another.

## Firebase Admin SDK helper (server-side only)

The provided Firebase Admin initialization snippet is integrated in `admin/firebase-admin-check.cjs`. It is an optional server-side connectivity check and is not bundled into the GitHub Pages site. Never put a service-account JSON or private key into `index.html` or commit one to the repository. See `FIREBASE-ADMIN-SETUP.md` for secure local setup. This helper does not replace the browser Firebase SDK or Firestore security rules used by mobile and desktop sync.


## v1.15.1 improvements

- Assign notes to existing Subject folders, Notes-only folders, or both. Filter Notes by either folder type, and create notes directly in the currently selected folder.
- Save subject-folder membership into the note record so the assignment remains synchronized across devices.
- Improve pasting from clipboard image items, clipboard file lists, and embedded image data in copied HTML. The Add image picker is a supported fallback on iOS/mobile browsers.
- Compress image uploads to a maximum 1280-pixel edge and target 700 KB or less to improve paste reliability and reduce storage transfer.
- Prevent the editor from rerendering underneath the native image picker and insert content at the remembered caret position.

## v1.15.0 improvements

- Notes are excluded from Calendar month, week, agenda, selected-day details, reminders, and exported calendar images.
- Notes now use a rich-text editor with bold, italic, underline, strikethrough, headings, quotes, bulleted lists, numbered lists, and clear-format controls.
- Notes can be organized in their own folders, separate from task folders. Folder changes sync to other devices through the existing per-user Firestore record path.
- Paste an image directly from the clipboard into a note on supported desktop/mobile browsers, or use Add image. Images are resized/compressed and uploaded to the signed-in user's Firebase Storage path, then embedded in the note; images are removed from Storage when their note is deleted.
- Updated the service-worker shell cache version to ensure clients receive the new Notes UI.

## v1.14.4 improvements

- Firebase CLI configuration now registers both Firestore and Storage rules.
- Profile picture uploads show progress, actionable permission errors, and a safe initials fallback if the remote image cannot load.
- Mobile gets direct bottom navigation for Calendar, Tasks, Checklist, and Notes.
- Delete actions use one ID-based flow and display clear cloud-delete failures; pending deletes can be retried from the sync control.

## v1.14.3 improvements (included in v1.14.4)

- Delete tasks, notes, checklists, and folders with a consistent in-app confirmation dialog on both desktop and mobile.
- Create a checklist with one tap and add steps inline without opening the full task editor.
- Receive a subtle due-soon popup while Dayframe is open. New and legacy tasks default to a 10-minute reminder; choose No reminder to disable it, or allow browser notifications for operating-system alerts. All-day tasks without a time use 9:00 AM as their reminder time.
- Export PNG calendars with adaptive resolution capped to reduce mobile memory usage. Supported mobile browsers offer the share sheet; other browsers download the image.

## Firestore security rules

The root `firestore.rules` contains the supplied owner-only rule: requests must be authenticated, and the signed-in Firebase UID must match the user ID in the document path. `firebase.json` points the Firebase CLI at that file, and `.firebaserc` selects the configured Firebase project. To publish both rules files, run `npx firebase-tools login` and then `npx firebase-tools deploy --only firestore:rules,storage` from the repository root. This is a separate Firebase deployment from GitHub Pages; a successful Pages deployment does not publish Firebase rules automatically. See `FIREBASE-SETUP.md`.

## Before using the app

Complete `FIREBASE-SETUP.md`: enable Email/Password Authentication, create Cloud Firestore and Firebase Storage, publish `firestore.rules` and `storage.rules`, and authorize your HTTPS deployment hostname. Login-ID-only accounts do not have a recovery email and cannot receive password-reset messages, so users must keep their password safe. If that is unacceptable, use an account provider that can verify and recover identities.

## Deploy

Commit the whole project to the root of a GitHub repository, including `.github/workflows/deploy-pages.yml`. In **Settings → Pages**, choose **GitHub Actions**. Then finish the Firebase setup above. The individual `index.html` is a source artifact; for cross-device Firebase use, host it on HTTPS rather than opening it from `file://`.

## Existing app features

- The calendar renders from the local account cache while Firebase refreshes in the background.
- Calendar items are grouped by date to reduce repeat work for month and week views.
- Responsive layout rules cover calendar, tasks, meetings, checklists, notes, folders, attachments, and modal forms.
- Calendar views can be exported as a high-resolution PNG.
- Dayframe branding is used in the app, favicon, and installable app icons.

## v1.14.2 mobile and quiet auto-save improvements (included in v1.14.4)

- Mobile devices open to the full Tasks list; Calendar opens in a readable Agenda view.
- Tightened mobile overflow, toolbar wrapping, calendar sizing, notes sizing, and touch targets.
- Removed routine save-success popups and visible per-write loading text; writes remain local-first and sync in the background with quiet retries for transient cloud errors. Firebase listeners attach without waiting for an initial server read, and cache-only snapshots cannot trigger recovery uploads.
- Note editing continues to auto-save locally and syncs to Firebase without blocking typing.
- Added an explicit account-sharing warning and account-switch guards so writes cannot continue in a newly active account after a session change.

## v1.14.1 cross-device sync recovery

On sign-in, Dayframe reconciles the freshest browser cache with the Firebase events and folders collections. Local-only records and records with newer local `updatedAt` timestamps are submitted to Firestore instead of being discarded when the cloud already contains other records. Live listeners preserve local changes while writes are pending. Failed writes remain visible locally and are retried when connectivity returns or the app becomes visible again. Pending deletions are also saved in a per-account recovery journal so offline deletes are not resurrected after a refresh. The compact sync button is available on mobile and desktop; tap it to compare the active Login ID and short account reference.

To recover older desktop-only items, deploy this version, open it on the original desktop browser, sign in with the exact same Login ID used on mobile, and keep it online until the sync status indicates that pending items have cleared. Then refresh Dayframe on mobile. If permissions are misconfigured or the devices use different Firebase accounts, the items will not appear on both devices; check the on-screen sync error and Firebase Console.

See `previews/dayframe-v1.14.0-preview.png` for an illustrative desktop layout preview (sample items, not user data; the current release includes mobile-specific behavior beyond this older preview). For device recovery steps, see `CROSS-DEVICE-RECOVERY.md`.

## Cross-device deletion safety

v1.14.4 records a minimal deletion marker in Firestore instead of hard-deleting the document path immediately. It prevents an offline device with stale cached data from restoring the deleted task when it reconnects. The deleted task content is replaced by its ID and deletion timestamps. Server-confirmed deletion markers cannot be overwritten by an old cached edit; if an already-open editor tries to save a deleted item, that stale edit is discarded.
