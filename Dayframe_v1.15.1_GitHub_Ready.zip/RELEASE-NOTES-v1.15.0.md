# Dayframe v1.15.0 release notes

## Notes and Calendar separation
- Notes and Notes-folder metadata are explicitly filtered out of Calendar month/week/agenda views, selected-day details, general task views, due reminders, and calendar PNG exports.
- Notes remain independently accessible under the Notes toggle and continue syncing under the signed-in user's existing Firestore account.

## Rich-text notes
- Added bold, italic, underline, strikethrough, headings, quotes, bulleted lists, numbered lists, and clear-format controls.
- Existing plain-text notes remain readable and are upgraded to rich-text-compatible content without changing their content.
- Rich text is sanitized before being stored or re-rendered to exclude executable markup and unsafe attributes.

## Notes folders
- Added Notes-specific folders, including create, rename, delete, filter, and per-note folder assignment.
- Deleting a folder retains its notes and moves them to All notes. Notes folders are separate from task/subject folders.

## Image paste
- Paste clipboard images directly in the note editor on browsers that expose image clipboard data. An Add image control provides a fallback for mobile browsers.
- Pasted images are compressed, uploaded to `users/<uid>/notes/<noteId>/` in Firebase Storage, and embedded using a download URL. The note stores only the URL and storage path metadata, not Base64 image bytes.
- Deleting a note triggers Storage cleanup for images it uploaded. Firebase Storage must be enabled and `storage.rules` published as documented in `FIREBASE-SETUP.md`.

## Deployment and verification
- Release marker and service-worker cache version: `1.15.0`.
- Run `python tests/test_v1_15_0.py` plus the existing release regression suite and `python tests/check_js_syntax.py`.
- Automated checks cover application wiring and data filtering; they do not replace live Firebase testing or checks on an actual iPhone/Android device and desktop browser.
