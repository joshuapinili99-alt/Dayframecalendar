"""Regression checks for Dayframe v1.15.1 subject-folder Notes and clipboard image reliability."""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
sw = (ROOT / 'sw.js').read_text(encoding='utf-8')
workflow = (ROOT / '.github/workflows/deploy-pages.yml').read_text(encoding='utf-8')
release = (ROOT / 'RELEASE-NOTES-v1.15.1.md').read_text(encoding='utf-8')
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

check('App, service worker, CI version gate, and release notes are v1.15.1', '<meta name="dayframe-version" content="1.15.1">' in html and "const VERSION='1.15.1'" in sw and 'content="1.15.1"' in workflow and 'v1.15.1' in release)
check('Notes editor exposes separate Subject and Notes folder selectors', 'id="note-subject-folder-assignment"' in html and 'id="note-folder-assignment"' in html and 'Move note to a subject folder' in html)
check('Notes folder filter has separate subject-folder and Notes-folder groups', '<optgroup label="Subject folders">' in html and '<optgroup label="Notes folders">' in html and 'value="subject:${esc(folder.id)}"' in html and 'value="notes:${esc(folder.id)}"' in html)
check('Subject-folder selection updates and persists folderId with a note', "updateNoteDraft('folderId',e.target.value)" in html and "folderId:String(item.folderId||'')" in html and "folderId:target.type==='subject'?target.id:''" in html)
check('New notes created while filtering either folder type are assigned to that folder', "target=noteFolderFilterParts(state.noteFolderFilter)" in html and "noteFolderId:target.type==='notes'?target.id:''" in html)
check('Note cards display and immediately refresh their subject and Notes folder memberships', "state.folders.find(f=>f.id===item.folderId)" in html and "noteFolders().find(f=>f.id===item.noteFolderId)" in html and 'function refreshNoteCardFolders(item)' in html and 'Subject:' in html)
check('Subject-folder deletion can clear membership without deleting the note', "for(const event of state.events.filter(e=>e.folderId===id))saveLocalRecord('events',event.id,'update',{folderId:''" in html and "e.kind==='note'" in html)
check('Notes still remain excluded from Calendar, task lists, date details, reminders, and exports', "function isNotesEntity(item){return ['note','noteFolder'].includes(item?.kind)}" in html and 'e.date===state.selected&&!isNotesEntity(e)' in html and "sortedEvents().filter(e=>!e.deletedAt&&!isNotesEntity(e))" in html)
check('Clipboard image detection checks both clipboard items and clipboard.files', 'function clipboardImageFile(clipboard)' in html and 'clipboard.items||[]' in html and 'clipboard.files||[]' in html)
check('Pasted HTML data-URI images are converted to files and uploaded before sanitization', 'function dataImageUriToFile(src,index=0)' in html and 'async function pasteNoteHtml(editor,html,savedRange)' in html and 'dataImages.length>5' in html and "img.setAttribute('src',uploaded.url)" in html)
check('Clipboard and file-picker image paths share the same Firebase upload helper', 'async function uploadNoteImageFile(file,noteId,userId)' in html and 'await uploadNoteImageFile(file,id,userId)' in html and 'await uploadBytes(storageRef(firebaseStorage,path),compressed' in html and 'await getDownloadURL(storageRef(firebaseStorage,path))' in html)
check('Pasted images are resized to 1280px and capped around 700 KB', 'compressImage(file,1280,.68,700*1024)' in html and 'Image added (' in html)
check('Image paste preserves caret range and avoids replacing the editor while using the file picker', 'function captureNoteRange(editor)' in html and 'function readNoteSelectionRange(editor)' in html and 'function insertNoteHtmlAtRange(editor,html,range)' in html and 'insertNoteHtmlAtRange(editor,parsed.body.innerHTML,savedRange)' in html and 'class="note-image-input"' in html and "body?.addEventListener('blur',()=>{flushNoteAutosave()})" in html and "state.noteSavedRange=readNoteSelectionRange(body)||state.noteSavedRange||captureNoteRange(body)" in html)
check('Storage error paths clean up partial uploads and tell the user how image paste failed', 'if(path)deleteObject(storageRef(firebaseStorage,path)).catch(()=>{})' in html and "notify(`Could not add this image:" in html)
check('Release notes explain folder assignment, clipboard fallback, compression, and limits of browser support', 'subject folders' in release.lower() and '700 KB' in release and 'iOS' in release and 'Firebase Storage' in release)
check('GitHub Pages CI runs the new v1.15.1 regression test', 'python tests/test_v1_15_1.py' in workflow)

# Exercise the actual folder normalization helpers in Node.js with both folder classes and a legacy Notes-folder ID.
node = shutil.which('node')
if node:
    helper_lines = [line for line in html.splitlines() if line.startswith('function normalizeNoteFolderFilter(value){') or line.startswith('function noteFolderFilterParts(value){')]
    if len(helper_lines) != 2:
        checks.append(('Subject/Notes folder filter namespace behavior test', False))
    else:
        harness = '''const assert=require('node:assert/strict');
const state={folders:[{id:'subject-A',name:'Biology'}],events:[{id:'nf-A',kind:'noteFolder',title:'Personal'}]};
function noteFolders(){return state.events.filter(item=>item.kind==='noteFolder')}
''' + '\n'.join(helper_lines) + '''
assert.deepEqual(noteFolderFilterParts('all'),{type:'all',id:''});
assert.deepEqual(noteFolderFilterParts('subject:subject-A'),{type:'subject',id:'subject-A'});
assert.deepEqual(noteFolderFilterParts('notes:nf-A'),{type:'notes',id:'nf-A'});
assert.deepEqual(noteFolderFilterParts('nf-A'),{type:'notes',id:'nf-A'});
assert.deepEqual(noteFolderFilterParts('subject:missing'),{type:'all',id:''});
console.log('PASS: subject folders, Notes folders, legacy folder IDs, and missing IDs normalize correctly');
'''
        result = subprocess.run([node, '-e', harness], capture_output=True, text=True)
        checks.append(('Subject/Notes folder filter namespace behavior test', result.returncode == 0 and 'PASS:' in result.stdout))
        if result.returncode:
            print(result.stdout, end=''); print(result.stderr, end='')
else:
    print('SKIP: Node.js unavailable; folder filter behavior harness not executed')

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} v1.15.1 regression checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed))
    sys.exit(1)
