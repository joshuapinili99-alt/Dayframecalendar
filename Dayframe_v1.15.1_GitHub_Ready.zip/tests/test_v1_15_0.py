"""Regression checks for Dayframe v1.15.0 Notes privacy, rich text, folders, and image paste."""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
sw = (ROOT / 'sw.js').read_text(encoding='utf-8')
workflow = (ROOT / '.github/workflows/deploy-pages.yml').read_text(encoding='utf-8')
release = (ROOT / 'RELEASE-NOTES-v1.15.0.md').read_text(encoding='utf-8')
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

html_version = re.search(r'<meta name="dayframe-version" content="([0-9.]+)">', html)
sw_version = re.search(r"const VERSION='([0-9.]+)'", sw)
workflow_version = re.search(r'<meta name="dayframe-version" content="([0-9.]+)">', workflow)
check('HTML, service worker, and GitHub deployment workflow use one consistent release version', bool(html_version and sw_version and workflow_version and html_version.group(1) == sw_version.group(1) == workflow_version.group(1)))
check('Notes and note-folder records are centrally excluded from normal planner views', "function isNotesEntity(item){return ['note','noteFolder'].includes(item?.kind)}" in html and "else list=list.filter(e=>!isNotesEntity(e))" in html)
check('Selected-day details and due reminders exclude all Notes entities', "e.date===state.selected&&!isNotesEntity(e)" in html and 'if(isNotesEntity(item)||item.done||item.reminderMinutes' in html)
check('Calendar PNG export excludes Notes entities', "sortedEvents().filter(e=>!e.deletedAt&&!isNotesEntity(e))" in html)
check('Rich-text controls include bold, italic, underline, strike, bullet/number lists, headings, quotes, and clear formatting', all(f'data-note-format="{command}"' in html for command in ['bold','italic','underline','strikeThrough','insertUnorderedList','insertOrderedList','formatBlock','removeFormat']) and 'data-note-value="blockquote"' in html)
check('The note editor is contenteditable and retains backward compatibility with plain-text notes', 'contenteditable="true"' in html and 'function noteEditorInitialHtml(item)' in html and "return esc(item.notes||'').replace(/\\r?\\n/g,'<br>')" in html)
check('Rich note HTML is sanitized and plain text previews/search content remain available', 'function sanitizeNoteHtml(html)' in html and 'function noteHtmlToText(html)' in html and "const href=child.getAttribute('href'),src=child.getAttribute('src')" in html and 'restoreNoteSelection(next,notePoints)' in html)
check('Notes have their own folders with create, rename, delete, filter, and assignment controls', all(x in html for x in ['function noteFolders()', 'function createNoteFolder()', 'function renameNoteFolder(id)', 'function deleteNoteFolder(id)', 'id="notes-folder-filter"', 'id="note-folder-assignment"', 'noteFolderId']))
check('Deleting a notes folder keeps its notes and moves them to All notes', "message:'Notes inside this folder will be kept and moved to All notes.'" in html and "saveLocalRecord('events',item.id,'update',{noteFolderId:''" in html)
check('Clipboard image paste and file-picker fallback normalize, downsize, and upload to the signed-in user Storage path', "body?.addEventListener('paste'" in html and 'clipboardImageFile(clipboard)' in html and 'id="note-image-input"' in html and 'compressImage(file,1280,.68,700*1024)' in html and 'users/${userId}/notes/${noteId}/' in html and 'await uploadBytes(' in html and 'await getDownloadURL(' in html and 'dataImageUriToFile(' in html)
check('Deleting a note attempts to remove its pasted note images from Firebase Storage', 'for(const path of e.noteImagePaths||[])' in html and "startsWith(`users/${state.user?.uid}/notes/`)" in html)
check('Release notes document mobile/desktop behavior and live Firebase testing limits', 'actual iPhone/Android device' in release and 'calendar PNG exports' in release and 'Paste clipboard images directly' in release)
check('GitHub Actions includes the v1.15.0 regression suite', 'python tests/test_v1_15_0.py' in workflow)

# Execute the actual shared filter code under Node with sample calendar, Notes, and completed records.
node = shutil.which('node')
if node:
    match1 = re.search(r'(function isNotesEntity\(item\)\{.*?\}\nfunction filteredEvents\(\)\{.*?\})\nfunction hoverCard', html, re.S)
    if not match1:
        checks.append(('Calendar/Notes data-filter behavior test', False))
        print('FAIL: Could not extract the planner view filters')
    else:
        harness = f'''const assert=require('node:assert/strict');
const state={{view:'Calendar',folderFilter:'all',events:[
 {{id:'task',kind:'task',title:'Task',date:'2026-10-23'}},
 {{id:'schedule',kind:'schedule',title:'Appointment',date:'2026-10-23'}},
 {{id:'note',kind:'note',title:'Private note',date:'2026-10-23',notes:'secret contents',done:true}},
 {{id:'noteFolder',kind:'noteFolder',title:'Private folder',date:'2026-10-23'}}
]}};
function sortedEvents(){{return state.events}}
{match1.group(1)}
state.view='Calendar';assert.deepEqual(filteredEvents().map(x=>x.id).sort(),['schedule','task']);
state.view='Tasks';assert.deepEqual(filteredEvents().map(x=>x.id),['task']);
state.view='Notes';assert.deepEqual(filteredEvents().map(x=>x.id),['note']);
state.view='Completed';assert.equal(filteredEvents().some(x=>x.kind==='note'||x.kind==='noteFolder'),false);
console.log('PASS: Calendar, Tasks, and Completed omit Notes; Notes toggle still shows Notes');
'''
        result = subprocess.run([node, '-e', harness], capture_output=True, text=True)
        checks.append(('Calendar/Notes data-filter behavior test', result.returncode == 0 and 'PASS:' in result.stdout))
        if result.returncode:
            print(result.stdout, end=''); print(result.stderr, end='')
else:
    print('SKIP: Node.js unavailable; filter behavior harness not executed')

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} v1.15.0 regression checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed))
    sys.exit(1)
