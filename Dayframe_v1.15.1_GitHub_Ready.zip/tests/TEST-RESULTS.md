# Dayframe v1.15.1 verification

## Latest release checks

- General application smoke checks: 33/33 passed.
- Firebase Admin SDK package integration checks: 9/9 passed.
- Firestore security-rule checks: 9/9 passed.
- v1.14.2 inherited mobile/autosave/account-isolation checks: 17/17 passed.
- v1.14.3 interactions, deletion, reminders, and export checks: 21/21 passed.
- v1.14.4 Storage, mobile navigation, and deletion-recovery checks: 21/21 passed.
- Cloud retry scheduler, sync reconciliation, and pending-delete journal tests: passed.
- Notes privacy/rich-text/folder and image workflow checks: 14/14 passed.
- v1.15.1 subject-folder assignment, clipboard image import, compression, and cache-version checks: 17/17 passed.
- JavaScript module syntax check: passed with Node.js.

These automated checks validate source-level wiring and simulated folder-filter behavior; they do not replace live Firebase sign-in/Storage tests or manual testing on physical iPhone, Android, and desktop browsers. Some mobile browsers do not expose copied image bytes to web pages; the Add image button is provided as a fallback.

---

# Dayframe v1.15.0 verification

- Notes/Calendar, Notes-only folders, safe rich text, image-paste wiring, cleanup hooks, and shared-filter behavior: 14/14 v1.15.0 regression checks passed.
- Inline JavaScript module syntax: passed.
- The existing full v1.14.x regression suite remains included and is run before release. These automated checks do not substitute for live Firebase sign-in/Storage checks or real iPhone/Android and desktop-browser validation.

# Dayframe v1.14.4 verification

- General application smoke checks: 33/33 passed.
- Firebase Admin SDK package integration checks: 9/9 passed.
- Firestore security-rule checks, including marker immutability: 9/9 passed.
- Inherited mobile/autosave/account-isolation regression checks: 17/17 passed.
- v1.14.3 interaction regression checks: 21/21 passed.
- v1.14.4 profile-photo, Storage deployment, mobile navigation, stale-delete, and tombstone regression checks: 21/21 passed.
- Sync reconciliation behavior test: passed.
- Cloud retry scheduler behavior test: passed.
- Pending-delete journal behavior test: passed.
- JavaScript module syntax check: passed with Node.js `--check`.
- ZIP integrity and secret-file checks: passed for the release archive.

These checks validate source-level regression behavior and packaging. They do **not** verify live Firebase Console configuration, actual authentication/storage permission on a deployed project, or real-device rendering on every Android/iOS/desktop browser. Publish the included Firestore and Storage rules and then test on physical devices after deployment. Due reminders display while Dayframe is open; operating-system notifications require permission, and push reminders while the app is fully closed are not implemented in this static GitHub Pages version.

---

# Dayframe v1.14.3 verification

- General application smoke checks: 33/33 passed.
- Admin SDK package integration checks: 9/9 passed.
- Firestore security-rule checks: 8/8 passed.
- Inherited mobile/autosave/account-isolation regression checks: 17/17 passed.
- v1.14.3 interaction regression checks: 21/21 passed.
- Sync reconciliation behavior test: passed. Verifies local-only tasks/folders, newer local edits, newer cloud records, legacy records without update timestamps, and pending edits/deletes.
- Cloud retry scheduler behavior test: passed. Verifies bounded backoff, active-account scoping, and timer cleanup.
- Pending-delete journal behavior test: passed. Verifies tombstone persistence, account-scoped restoration, exclusion of normal edits, and cleanup after acknowledgement.
- JavaScript module syntax check: passed with Node.js `--check`.
- ZIP integrity: passed on the final release archive.

These checks verify source wiring, static behavior, the existing reconciliation/retry logic, and packaging. They do not prove that Firebase is enabled or that real-device behavior is flawless. The release still needs live testing on an actual phone and desktop against the configured Firebase project. Due reminders work while Dayframe is open; when the page is hidden they can use operating-system notifications only if the browser grants permission. This static GitHub Pages app does not implement push reminders when completely closed.
