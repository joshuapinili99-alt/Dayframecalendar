# Dayframe release checks

From the project root, run:

```bash
python tests/test_smoke.py
python tests/test_admin_sdk_integration.py
python tests/test_sync_reconcile.py
python tests/test_v1_15_0.py
python tests/test_v1_15_1.py
python tests/check_js_syntax.py
```

The checks validate the release marker, Firebase configuration, Login ID mapping, Firestore listeners, responsive breakpoints, security-rule presence, Supabase removal, local/cloud reconciliation, protection of pending local writes, retry behavior, and v1.15.0 Notes/Calendar separation and rich-text features, plus v1.15.1 subject-folder connection and robust clipboard image handling.

The Admin SDK integration check verifies safe packaging and setup, not live cloud connectivity. Static checks and simulated reconciliation tests do not prove that Firebase services are enabled or that a live account can sign in. Finish `FIREBASE-SETUP.md`, deploy to HTTPS, and test on desktop and mobile using the exact same Login ID.
