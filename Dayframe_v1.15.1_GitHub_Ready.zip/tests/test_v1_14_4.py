"""Regression checks for Dayframe v1.14.4 profile pictures, mobile navigation, and cross-device deletion."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
sw = (ROOT / 'sw.js').read_text(encoding='utf-8')
workflow = (ROOT / '.github/workflows/deploy-pages.yml').read_text(encoding='utf-8')
notes = (ROOT / 'RELEASE-NOTES-v1.14.4.md').read_text(encoding='utf-8')
config = json.loads((ROOT / 'firebase.json').read_text(encoding='utf-8'))
storage_rules = (ROOT / 'storage.rules').read_text(encoding='utf-8')
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

check('HTML, service worker, and GitHub workflow use the current release marker', '<meta name="dayframe-version" content="1.15.1">' in html and "const VERSION='1.15.1'" in sw and 'content="1.15.1"' in workflow)
check('Firebase CLI configuration registers both Firestore and Storage rules', config.get('firestore', {}).get('rules') == 'firestore.rules' and config.get('storage', {}).get('rules') == 'storage.rules')
check('Storage rules restrict avatar and file access to the signed-in owner UID', 'match /users/{userId}/{allPaths=**}' in storage_rules and 'request.auth != null && request.auth.uid == userId' in storage_rules)
firestore_rules = (ROOT / 'firestore.rules').read_text(encoding='utf-8')
check('Firestore rules prevent normal updates from reviving tombstones', "resource.data.get('_dayframeDeleted', false) != true" in firestore_rules and "request.resource.data.get('_dayframeDeleted', false) == true" in firestore_rules and "allow delete: if isOwner() && resource.data.get('_dayframeDeleted', false) != true" in firestore_rules)
check('Profile upload includes iPhone HEIC/HEIF, size compression, and the expected user-owned Storage path', 'accept="image/*,.heic,.heif"' in html and 'compressImage(browserFile,320,.76,440*1024)' in html and 'users/${userId}/profile/avatar' in html)
check('Profile upload provides actionable Storage permission and missing-bucket messages', 'Publish storage.rules from this repository' in html and 'Enable Firebase Storage' in html and "'storage/unauthorized'" in html)
check('Broken remote profile image falls back to initials rather than showing a broken image', 'image.onerror=()=>{image.onerror=null;image.removeAttribute(\'src\');image.classList.add(\'hidden\');initials.classList.remove(\'hidden\')}' in html)
check('Profile photo can be stored in the user Auth profile as a secondary hint', 'firebaseUpdateProfile(firebaseAuth.currentUser,{photoURL})' in html)
check('Mobile bottom navigation provides one-tap Calendar, Tasks, Checklist, and Notes', 'id="mobile-tab-bar"' in html and all(f'data-view="{name}"' in html[html.index('id="mobile-tab-bar"'):html.index('</nav>',html.index('id="mobile-tab-bar"'))] for name in ['Calendar','Tasks','Checklist','Notes']))
check('Mobile navigation is fixed above the safe area and leaves room for page content and toast messages', '.mobile-tab-bar{position:fixed' in html and 'env(safe-area-inset-bottom)' in html and '.workspace{padding-bottom:calc(104px' in html and '.toast{bottom:calc(80px' in html)
check('Active state is synchronized across sidebar and mobile bottom navigation', "document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===state.view))" in html)
check('Edit-modal deletion uses the same event-ID handler as list deletion', 'data-delete-event="${esc(id)}">Delete item' in html and "if(b.hasAttribute('data-delete-event')){await deleteEvent(b.dataset.deleteEvent);return}" in html and 'delete-from-modal' not in html)
check('Deletions are represented as minimal cloud tombstones to prevent stale clients resurrecting old records', 'function isCloudTombstone(item)' in html and '_dayframeDeleted:true,deletedAt,updatedAt:deletedAt' in html and 'collectCloudTombstones' in html and "if(type!=='delete'&&cloudTombstonesFor(collectionName).has(docId))type='delete';" in html)
check('A stale open editor cannot re-add an item already marked deleted by another device', 'else if(cloudTombstonesFor(op.collection).has(op.docId)){' in html and 'pending.set(op.docId,null)' in html and 'The older edit was discarded.' in html)
check('Event and folder snapshots filter remote tombstones before reconciliation can re-upload cached records', "collectCloudTombstones('events',snapshotRecords)" in html and "collectCloudTombstones('folders',snapshotRecords)" in html and "filterCloudTombstones(mergeCloudWithPending(reconciled.items,'events'),'events')" in html and "filterCloudTombstones(mergeCloudWithPending(reconciled.items,'folders'),'folders')" in html)
check('Cloud deletion failures keep the local tombstone queued and explain how to retry', 'Cloud delete needs attention' in html and 'Deleted on this device, but Firebase has not confirmed the deletion' in html and 'remains queued here' in html)
check('Tapping the sync indicator retries pending cloud mutations when online', "if(state.user&&pending&&navigator.onLine){retryPendingCloudRecovery(state.user)}" in html)
check('The Firebase setup guide documents publishing both rules files', 'deploy --only firestore:rules,storage' in (ROOT/'FIREBASE-SETUP.md').read_text(encoding='utf-8'))
check('GitHub Actions runs the v1.14.4 regression suite', 'python tests/test_v1_14_4.py' in workflow)
check('Release notes explain live-device testing limits', 'real Android/iOS device testing' in notes)

# Exercise tombstone filtering and reconcile behavior without a browser or live Firebase credentials.
node = shutil.which('node')
if node:
    def extract(start, end):
        match = re.search(re.escape(start) + r'(.*?)' + re.escape(end), html, re.S)
        if not match:
            raise SystemExit(f'FAIL: Could not extract function block beginning {start!r}')
        return start + match.group(1)
    tombstone_fns = extract('function isCloudTombstone(item){', '\nfunction eventsCollection')
    clean_fn = extract('function cleanCloudRecord(value){', '\n// A remote tombstone')
    timestamp_fn = extract('function recordTimestamp(item){', '\nfunction mergeRecoveredDocs')
    merge_fn = extract('function reconcileCloudItems(remoteItems,localItems){', '\nfunction pendingRecoveryCount')
    apply_fn = extract('function applyLocalMutation(op){', '\nfunction saveLocalRecord')
    harness = f'''\nconst assert=require('node:assert/strict');\nconst state={{cloudTombstones:{{events:new Set(),folders:new Set()}},cloudRecovery:{{events:new Map([['deleted-1',{{id:'deleted-1',title:'stale queued edit'}}]]),folders:new Map()}},user:{{uid:'tester'}}}};\nfunction persistPendingDeletes(){{return Promise.resolve(true)}}\n{clean_fn}\n{timestamp_fn}\n{tombstone_fns}\n{merge_fn}\nconst remote=[{{id:'deleted-1',_dayframeDeleted:true,deletedAt:'2026-10-22T12:00:00.000Z',updatedAt:'2026-10-22T12:00:00.000Z'}},{{id:'keep-1',title:'Still active',updatedAt:'2026-10-22T11:00:00.000Z'}}];\ncollectCloudTombstones('events',remote);\nconst staleLocal=[{{id:'deleted-1',title:'Old cached task',updatedAt:'2026-10-20T11:00:00.000Z'}},{{id:'keep-1',title:'Stale title',updatedAt:'2026-10-20T11:00:00.000Z'}},{{id:'offline-new',title:'Offline-created',updatedAt:'2026-10-22T13:00:00.000Z'}}];\nconst prior=filterCloudTombstones(staleLocal,'events');\nconst fresh=filterCloudTombstones(remote,'events');\nconst result=reconcileCloudItems(fresh,prior);\nassert.equal(prior.some(x=>x.id==='deleted-1'),false,'remote tombstone removes stale cached item before reconciliation');
assert.equal(state.cloudRecovery.events.get('deleted-1'),null,'a remote deletion replaces a queued stale edit with a tombstone retry');\nassert.equal(result.items.some(x=>x.id==='deleted-1'),false,'deleted item stays hidden');\nassert.equal(result.toUpload.some(x=>x.id==='deleted-1'),false,'stale cached delete cannot re-upload the record');\nassert.equal(result.items.some(x=>x.id==='offline-new'),true,'genuine local-only item is retained for recovery');\nassert.equal(result.toUpload.some(x=>x.id==='offline-new'),true,'genuine local-only item can still sync');\nconsole.log('PASS: cloud tombstone blocks stale-cache resurrection while retaining legitimate offline-created records');\n'''
    result = subprocess.run([node, '-e', harness], capture_output=True, text=True)
    checks.append(('Cloud tombstone reconciliation behavior test', result.returncode == 0 and 'PASS:' in result.stdout))
    if result.returncode:
        print(result.stdout, end='')
        print(result.stderr, end='')
else:
    print('SKIP: Node.js unavailable; cloud tombstone behavior harness not executed')

failed = [name for name, condition in checks if not condition]
for name, condition in checks:
    print(f"{'PASS' if condition else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} v1.14.4 regression checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed))
    sys.exit(1)
