# Dayframe v1.15.1 release notes

## Connected Notes and subject folders
- Every note can now be assigned to an existing **Subject folder** and/or a separate **Notes folder**. Both assignments sync with the note record through the existing Firebase account.
- The Notes folder filter now includes both subject folders and Notes-only folders in separate groups. Selecting a subject folder shows the notes assigned to that subject, and creating a note while filtered assigns it to the selected folder.
- Notes cards show their subject-folder and Notes-folder memberships. Renaming a subject folder updates its label wherever it is used. Deleting a subject folder clears that membership but keeps the note.
- Notes remain excluded from Calendar, date details, Tasks, Completed, reminders, and calendar image exports.

## More reliable image paste
- Clipboard handling checks both the clipboard item list and the clipboard file list, and imports embedded `data:image` content from copied HTML before applying safe HTML sanitization.
- Clipboard and file-picker images use the same Firebase Storage upload routine. The editor inserts the uploaded image at the saved caret position; the Add image button remains available for browsers that do not expose image clipboard data.
- Images are resized to a maximum edge of 1280 pixels and compressed toward **700 KB or less** (WebP when supported) before upload to `users/<uid>/notes/<noteId>/`. This substantially reduces upload time and storage usage while keeping screenshots and ordinary photos practical for notes.
- The image picker no longer relies on a `display:none` file input, and Notes editor focus handling avoids tearing down the editor when opening the native file picker. Errors are surfaced to the user and partial failed uploads are cleaned up.

## Deployment and verification
- Release marker and service-worker cache version: `1.15.1`.
- Run `python tests/test_v1_15_0.py`, `python tests/test_v1_15_1.py`, and `python tests/check_js_syntax.py`, followed by the existing regression suite.
- Automated tests validate source wiring and simulated folder-filter behavior. They do not substitute for live Firebase Storage/auth testing or manual checks on physical iOS, Android, and desktop browsers. Browser security limits mean some mobile browsers do not expose copied image bytes to web pages; in those cases, use **Add image** to select the picture from Photos or Files. Firebase Storage must be enabled and `storage.rules` published as described in `FIREBASE-SETUP.md`.
