# Changelog

## v1.9.4
- Standardized the backend on the single Supabase table `public.dayframe`.
- Added `record_type` separation for events, folders, and profile photos while retaining existing planner features.
- Updated reads, writes, delete filters, profile-photo syncing, and Realtime subscriptions to target `public.dayframe`.
- Updated setup and repair SQL to secure the single table and migrate data from older Dayframe tables without deleting them.
- Bumped the service-worker cache version so deployed browsers fetch the new application shell.

## v1.9.3
- Improved Supabase schema-cache diagnostics and cross-device sync reliability.
- Added targeted repair guidance for missing database tables and schema cache.
