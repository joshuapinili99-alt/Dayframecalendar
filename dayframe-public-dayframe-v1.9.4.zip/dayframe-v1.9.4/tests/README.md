# Dayframe v1.9.4 automated smoke tests

`test_smoke.py` uses Playwright with `mock-supabase.js`, a simulated Supabase Auth/Postgres/Realtime/Storage client. It tests item writes, read/write ordering, polling fallback, checklist storage and individual checkbox updates, profile-photo compression/retry, attachment storage, and mobile layout.

Run from a Python environment with Playwright and Chromium installed:

```bash
python tests/test_smoke.py
```

The generated result summary is written to `tests/TEST-RESULTS.md`, and preview screenshots are written to `tests/desktop-preview.png` and `tests/mobile-preview.png`.

The suite uses a simulated client. It does not validate the live Supabase schema, RLS policies, Auth redirects, private signed URLs, or real-device network behavior.
