-- Dayframe v1.9.4 Supabase setup: one app table, public.dayframe
-- Run in Supabase Dashboard -> SQL Editor as the project owner.
-- Every row is user-scoped and protected by Row Level Security (RLS).

create table if not exists public.dayframe (
  user_id uuid not null references auth.users(id) on delete cascade,
  record_type text not null check (record_type in ('event', 'folder', 'profile')),
  id text not null,
  data jsonb not null default '{}'::jsonb,
  avatar_data_url text,
  updated_at timestamptz not null default now(),
  primary key (user_id, record_type, id)
);

-- If public.dayframe already existed, add the fields required by the current app
-- without replacing the table or deleting any rows. New fields remain nullable on
-- legacy rows if their owner/ID is unknown; new app writes always provide both.
alter table public.dayframe add column if not exists user_id uuid references auth.users(id) on delete cascade;
alter table public.dayframe add column if not exists id text;
alter table public.dayframe add column if not exists record_type text not null default 'event';
alter table public.dayframe add column if not exists data jsonb not null default '{}'::jsonb;
alter table public.dayframe add column if not exists avatar_data_url text;
alter table public.dayframe add column if not exists updated_at timestamptz not null default now();

-- This unique index is the upsert conflict target, including on installations
-- where public.dayframe existed before this version.
create unique index if not exists dayframe_user_record_id_uidx
  on public.dayframe (user_id, record_type, id);

-- Migrate records from older Dayframe versions if the legacy tables exist.
-- Existing rows in public.dayframe take precedence on re-runs.
do $$
begin
  if to_regclass('public.dayframe_events') is not null then
    execute $migrate_events$
      insert into public.dayframe (user_id, record_type, id, data, updated_at)
      select user_id, 'event', id, coalesce(data, '{}'::jsonb), coalesce(updated_at, now())
      from public.dayframe_events
      on conflict (user_id, record_type, id) do nothing
    $migrate_events$;
  end if;

  if to_regclass('public.dayframe_folders') is not null then
    execute $migrate_folders$
      insert into public.dayframe (user_id, record_type, id, data, updated_at)
      select user_id, 'folder', id, coalesce(data, '{}'::jsonb), coalesce(updated_at, now())
      from public.dayframe_folders
      on conflict (user_id, record_type, id) do nothing
    $migrate_folders$;
  end if;

  if to_regclass('public.dayframe_profiles') is not null then
    execute $migrate_profiles$
      insert into public.dayframe (user_id, record_type, id, data, avatar_data_url, updated_at)
      select user_id, 'profile', 'profile', '{}'::jsonb, avatar_data_url, coalesce(updated_at, now())
      from public.dayframe_profiles
      on conflict (user_id, record_type, id) do nothing
    $migrate_profiles$;
  end if;
end $$;

alter table public.dayframe enable row level security;
revoke all on table public.dayframe from public, anon;
grant select, insert, update, delete on table public.dayframe to authenticated;

drop policy if exists "Dayframe users own records" on public.dayframe;
create policy "Dayframe users own records"
  on public.dayframe for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

-- Use a private bucket. The app creates 7-day signed URLs and refreshes them
-- when the app is opened or returned to the foreground.
insert into storage.buckets (id, name, public, file_size_limit)
values ('dayframe-attachments', 'dayframe-attachments', false, 10485760)
on conflict (id) do update
set public = false, file_size_limit = 10485760;

drop policy if exists "Dayframe users read own attachments" on storage.objects;
create policy "Dayframe users read own attachments"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  );

drop policy if exists "Dayframe users upload own attachments" on storage.objects;
create policy "Dayframe users upload own attachments"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  );

drop policy if exists "Dayframe users update own attachments" on storage.objects;
create policy "Dayframe users update own attachments"
  on storage.objects for update to authenticated
  using (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  )
  with check (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  );

drop policy if exists "Dayframe users delete own attachments" on storage.objects;
create policy "Dayframe users delete own attachments"
  on storage.objects for delete to authenticated
  using (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  );

-- Enable Realtime for cross-device changes; safe to run more than once.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin
      alter publication supabase_realtime add table public.dayframe;
    exception when duplicate_object then null;
    end;
  else
    raise notice 'Realtime publication supabase_realtime was not found. Dayframe will use its 12-second refresh fallback; enable Realtime for public.dayframe in the Supabase Dashboard for faster updates.';
  end if;
end $$;

alter table public.dayframe replica identity full;

-- Verify the single app table and its Realtime membership.
select table_schema, table_name
from information_schema.tables
where table_schema = 'public' and table_name = 'dayframe';

select schemaname, tablename
from pg_publication_tables
where pubname = 'supabase_realtime'
  and schemaname = 'public'
  and tablename = 'dayframe';

-- Refresh PostgREST's schema cache so public.dayframe is immediately discoverable.
notify pgrst, 'reload schema';
