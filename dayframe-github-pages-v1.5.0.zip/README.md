# Dayframe v1.5.0

A responsive personal planner with Calendar, To-do lists, Meetings, Notes, Completed items, folders, compact compressed profile photos, and Firebase synchronization.

## Quick deployment to GitHub Pages

This repository includes `.github/workflows/deploy-pages.yml`. It publishes the app to GitHub Pages whenever you push to `main`.

1. Download and extract the `dayframe-github-pages-v1.5.0.zip` file.
2. Create a new GitHub repository and upload the **contents of the extracted folder** to the repository root. Do not upload only the ZIP itself.
3. Commit the files to the `main` branch.
4. In the repository, open **Settings → Pages**. Set the deployment source to **GitHub Actions**.
5. Open **Actions** and wait for **Deploy Dayframe to GitHub Pages** to finish. GitHub will show the deployed URL in the Pages settings and workflow result.
6. In Firebase Console → Authentication → Settings → Authorized domains, add the host part of your Pages URL (for example `your-username.github.io`, without `https://` or any path).
7. Review the rules in `firebase-setup/firestore.rules` and publish them. If your Firebase project is dedicated to Dayframe, you can use that file as the complete ruleset. If the project is shared with other apps, merge the Dayframe rules into your existing rules instead of replacing unrelated rules.

Official GitHub documentation: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

## Fixes in v1.5.0

- Local record cache and pending cloud writes are kept in both localStorage and IndexedDB. Cloud sync does not depend on localStorage being writable.
- Pending writes are retried automatically after transient network errors with backoff. The sync indicator is visible on phones and can be tapped to retry queued changes.
- On returning to a mobile browser tab, the app attempts to flush pending writes and reattach the data listener.
- Profile photos are compressed to a small image, previewed and queued locally first, then saved in the user's Firestore profile document, avoiding Firebase Storage for avatars. If a cloud write fails, the local preview and queued payload remain for retry from the sync indicator or after reconnecting. iPhone HEIC/HEIF files are converted in supported browsers through a lazily loaded converter; JPG/PNG/WebP remain the most reliable choices.
- Firebase error reporting is more specific for missing Storage setup, permissions, quota, or billing restrictions.
- The service worker cache was bumped to v1.5.0 so installed app shells update.

## Firebase data and billing requirements

Task, meeting, note, folder, and profile-avatar records use Firestore. The new Firestore rules allow each signed-in user to access only their own records. Publish those rules before testing the new avatar feature.

Event attachments still use Firebase Cloud Storage. As of the current Firebase policy, Cloud Storage requires the Blaze pay-as-you-go plan, although usage may fall within no-cost allowances depending on the bucket and use. Read Firebase's official note and set budget alerts before enabling billing:

- https://firebase.google.com/docs/storage/faqs-storage-changes-announced-sept-2024
- https://firebase.google.com/docs/storage/web/start

If you do not enable Cloud Storage, planner records and Firestore-based profile photos can still sync, but event attachment uploads cannot.

## Important data-saving check

A **local backup** is not proof a change reached Firebase. After deploying, create a test task and wait for `Synced`, then refresh and verify the task is still present. Test the same account on a second device. If the status reports a sync issue, tap it to retry after checking Firestore rules and connectivity. Never clear site data while a pending-sync error is visible.

## Tests

See `tests/TEST-RESULTS.md` for the automated smoke tests. They use a simulated Firebase adapter; live project rules, billing configuration, and cross-device sync still require an actual deployment test. For recommended follow-up features and production-readiness improvements, see `IMPROVEMENTS-ROADMAP.md`.
