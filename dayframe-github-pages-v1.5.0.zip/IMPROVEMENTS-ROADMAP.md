# Dayframe improvement roadmap

This is a prioritized list for improving the planner beyond the current v1.5.0 reliability and mobile changes.

## Priority 1: Data safety and recovery

- Add **Export my data** and **Import backup** using a versioned JSON format. Exports should include events, folders, and notes, while attachment files should be downloaded separately or included in a ZIP.
- Add a small sync history panel that shows the last confirmed cloud save and the last error, without exposing technical details unless the user expands them.
- Add duplicate/conflict detection for edits made on two devices at once. Use a record revision or `updatedAt` check before applying overwrites.
- Add a clear sign-out warning if cloud writes are still pending, and never clear a user's local recovery queue until the same user's cloud writes are confirmed or the user explicitly discards them.

## Priority 2: Mobile usability

- Test physical iPhone Safari and Android Chrome at narrow widths, in portrait and landscape, with the on-screen keyboard open.
- Add a dedicated bottom navigation bar for Calendar, Tasks, Meetings, Notes, and More, while preserving the desktop sidebar.
- Add an install prompt/instructions for the Progressive Web App and an offline indicator that distinguishes **saved on this device** from **confirmed in Firebase**.
- Improve accessibility with screen-reader announcements for save outcomes, larger minimum hit targets, clear focus outlines, and reduced-motion support.

## Priority 3: Planner productivity

- Add search across task titles, notes, meetings, folders, and attachment filenames.
- Add recurring tasks and meetings, with explicit handling for editing one occurrence versus an entire series.
- Add calendar drag-and-drop rescheduling on desktop, with a touch-friendly reschedule flow on phones.
- Add optional reminders. Browser notifications require permission and can be restricted by mobile browser/platform; reliable server-scheduled reminders may need an additional backend.

## Priority 4: Performance and attachments

- For very large accounts, query events by date range and paginate list views rather than loading every event into every session.
- Add upload progress, cancel, and explicit retry for each attachment. Retrying must preserve the original file until upload is confirmed.
- Consider direct Cloud Storage URLs with short-lived authenticated access rather than long-lived download token URLs, depending on the desired sharing and privacy model.
- Set Firestore and Storage budgets/alerts and review access rules as features evolve.

## Before calling the app production-ready

Run Firebase Emulator Suite tests for security rules, test the exact Firebase project configuration, and do real-device checks on iPhone Safari and Android Chrome. Mock tests are useful for regression detection but cannot prove a deployment is completely bug-free.
