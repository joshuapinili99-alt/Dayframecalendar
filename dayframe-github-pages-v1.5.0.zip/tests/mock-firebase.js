(() => {
  try {
    const memory = new Map();
    const localStore = {
      getItem: k => memory.has(k) ? memory.get(k) : null,
      setItem: (k, v) => {
        if (window.__mockDayframe?.failLocalStorage) throw new DOMException('Simulated localStorage quota/block', 'QuotaExceededError');
        memory.set(k, String(v));
      },
      removeItem: k => memory.delete(k),
      clear: () => memory.clear()
    };
    Object.defineProperty(window, 'localStorage', { configurable: true, value: localStore });
  } catch (_) {}
  const data = { events: new Map(), folders: new Map(), profile: new Map() };
  const listeners = { events: new Set(), folders: new Set(), profile: new Set() };
  const storage = new Map();
  let failRecoveryOnce = true;
  function snap(kind) {
    return { docs: [...data[kind].entries()].map(([id, v]) => ({ id, data: () => ({ ...v }) })), metadata: { fromCache: false } };
  }
  function notify(kind) { for (const cb of listeners[kind] || []) cb(snap(kind)); }
  const user = { uid: 'mock-user-1', displayName: 'Taylor Demo', email: 'taylor@example.com', photoURL: null, async updateProfile(p) { Object.assign(this, p); } };
  const authApi = {
    async setPersistence() {}, getRedirectResult() { return Promise.resolve(null); },
    onAuthStateChanged(cb) { setTimeout(() => cb(user), 30); return () => {}; },
    async signOut() {}, async createUserWithEmailAndPassword() { return { user }; },
    async signInWithEmailAndPassword() { return { user }; }, async sendPasswordResetEmail() {}
  };
  function auth() { return authApi; }
  auth.Auth = { Persistence: { LOCAL: 'local', SESSION: 'session' } };
  auth.GoogleAuthProvider = function() {};
  function collectionRef(kind) {
    if (!data[kind]) data[kind] = new Map();
    if (!listeners[kind]) listeners[kind] = new Set();
    return {
      doc(id) {
        return {
          async get() { const v = data[kind].get(id); return { exists: !!v, data: () => v ? { ...v } : undefined }; },
          async set(v) {
            await new Promise(resolve => setTimeout(resolve, 90));
            if (kind === 'events' && v.title === 'Recovery test' && failRecoveryOnce) {
              failRecoveryOnce = false;
              throw { code: 'unavailable', message: 'Simulated network interruption' };
            }
            if (kind === 'profile' && window.__mockDayframe?.failProfileOnce) {
              window.__mockDayframe.failProfileOnce = false;
              throw { code: 'permission-denied', message: 'Simulated profile rules rejection' };
            }
            data[kind].set(id, { ...v, id }); notify(kind);
          },
          async update(v) {
            if (!data[kind].has(id)) throw { code: 'not-found', message: 'missing doc' };
            data[kind].set(id, { ...data[kind].get(id), ...v, id }); notify(kind);
          },
          async delete() { data[kind].delete(id); notify(kind); }
        };
      },
      onSnapshot(opts, cb) {
        if (typeof opts === 'function') cb = opts;
        listeners[kind].add(cb); setTimeout(() => cb(snap(kind)), 10);
        return () => listeners[kind].delete(cb);
      }
    };
  }
  const db = {
    async enablePersistence() {},
    collection(name) { return { doc(uid) { return { collection(kind) { return collectionRef(kind); } }; } } }
  };
  function storageApi() {
    return { ref(path) { return {
      async put(file, metadata) { storage.set(path, { file, metadata }); return { ref: this }; },
      async getDownloadURL() { return 'https://mock-storage.invalid/' + encodeURIComponent(path) + '?token=mock'; },
      async delete() { storage.delete(path); }
    }; } };
  }
  // Lightweight IndexedDB test double: exercises the app's actual IDB API path in a sandboxed set_content page.
  const idbRecords = new Map();
  let objectStoreCreated = false;
  const fakeIndexedDB = {
    open() {
      const request = {};
      setTimeout(() => {
        const database = {
          objectStoreNames: { contains(name) { return objectStoreCreated && name === 'records'; } },
          createObjectStore(name) { objectStoreCreated = name === 'records'; return {}; },
          transaction() {
            const tx = {};
            const store = {
              put(record) { idbRecords.set(record.key, { ...record }); setTimeout(() => tx.oncomplete?.(), 0); return {}; },
              get(key) { const req = {}; setTimeout(() => { req.result = idbRecords.get(key); req.onsuccess?.(); }, 0); return req; },
              delete(key) { idbRecords.delete(key); setTimeout(() => tx.oncomplete?.(), 0); return {}; }
            };
            tx.objectStore = () => store;
            return tx;
          }
        };
        request.result = database;
        request.onupgradeneeded?.();
        request.onsuccess?.();
      }, 0);
      return request;
    }
  };
  try { Object.defineProperty(window, 'indexedDB', { configurable: true, value: fakeIndexedDB }); } catch (_) { window.indexedDB = fakeIndexedDB; }
  window.__mockDayframe = { data, storage, user, failLocalStorage: false, failProfileOnce: false, idbRecords };
  window.firebase = { apps: [], initializeApp() { this.apps.push({}); }, auth, firestore() { return db; }, storage: storageApi };
})();
