# Automated smoke tests

`test_smoke.py` uses Playwright with Chromium, a simulated Firebase adapter, and an IndexedDB test double to check core UI and save paths. The package is a static HTML app and does not need a build step.

To run in an environment with Python Playwright and Chromium installed:

```bash
python tests/test_smoke.py
```

The current v1.5.0 run passes 25 checks. The harness does not test live Firebase rules, a real iPhone HEIC conversion, a real GitHub Pages deployment, real device storage, real network latency, or cross-device synchronization. See `TEST-RESULTS.md`.
