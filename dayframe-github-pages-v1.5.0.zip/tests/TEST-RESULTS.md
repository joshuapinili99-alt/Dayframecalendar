# Dayframe v1.5.0 automated smoke-test results

**Result: 25/25 checks passed** on the final source used for this ZIP.

## Covered checks

- Desktop dashboard renders with mock authentication.
- Calendar date-add buttons render and preselect the clicked date.
- Sync state is visible on desktop and phone.
- Planner tasks save through the mocked Firestore adapter.
- Profile photos are compressed and saved as Firestore data URLs, without Firebase Storage calls.
- When a profile-photo cloud write is rejected, the local preview and durable avatar queue remain; tapping the sync status retries the photo and clears the queue on successful cloud write.
- Pending planner changes are retained in the IndexedDB API fallback when localStorage writes fail.
- Pending profile-photo writes survive a simulated Firestore rejection and retry successfully.
- A simulated transient cloud-write error is retried when the browser comes back online.
- Mobile layout has no horizontal page overflow at 390 px.
- Mobile Show/Hide details and navigation drawer behaviors work.
- A mobile note saves through the mocked cloud adapter while localStorage is unavailable.
- No uncaught JavaScript runtime errors occurred during the tested desktop and mobile flows.
- The main inline JavaScript passes `node --check` syntax validation.

## Test limitations

These are automated smoke tests using a **simulated Firebase adapter** and a small IndexedDB test double. They do not contact the live Firebase project and do not verify actual Firestore rules, Google authentication configuration, Storage billing, GitHub Pages deployment, real network latency, or physical iPhone/Android devices. Before production use, follow the root README and `firebase-setup/README.md`, then test the deployed HTTPS site on a phone and desktop using the same Firebase account.
