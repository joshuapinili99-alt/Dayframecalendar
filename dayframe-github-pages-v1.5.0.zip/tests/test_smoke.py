"""Playwright smoke test for Dayframe v1.5.0.

Uses set_content and a mock Firebase adapter so it does not touch a live project.
Run with: python -m pip install playwright; install a Chromium browser; python tests/test_smoke.py
"""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
RESULTS = []

html = (ROOT / 'index.html').read_text(encoding='utf-8')
mock = (ROOT / 'tests' / 'mock-firebase.js').read_text(encoding='utf-8')
sw_source = (ROOT / 'sw.js').read_text(encoding='utf-8')
pattern = r'<script src="https://www\.gstatic\.com/firebasejs/12\.4\.0/firebase-app-compat\.js"></script>\s*<script src="https://www\.gstatic\.com/firebasejs/12\.4\.0/firebase-auth-compat\.js"></script>\s*<script src="https://www\.gstatic\.com/firebasejs/12\.4\.0/firebase-firestore-compat\.js"></script>\s*<script src="https://www\.gstatic\.com/firebasejs/12\.4\.0/firebase-storage-compat\.js"></script>\s*<script>'
html, count = re.subn(pattern, '<script>' + mock + '</script>\n<script>', html, count=1)
if count != 1:
    raise RuntimeError('Could not inject the mock Firebase adapter into index.html')


def check(name, condition):
    RESULTS.append((name, bool(condition)))

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None, headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
    context = browser.new_context(viewport={'width': 1280, 'height': 900}, service_workers='block')
    page = context.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(html, wait_until='domcontentloaded')
    page.wait_for_selector('#app:not(.hidden)', timeout=10000)
    page.wait_for_selector('.calendar-grid', timeout=10000)
    page.wait_for_timeout(200)
    check('service worker cleanup preserves caches from other apps', "key.startsWith('dayframe-shell-')&&key!==CACHE" in sw_source)
    check('desktop dashboard renders with mock auth', page.locator('.calendar-grid').count() == 1)
    check('desktop date-specific add buttons are rendered', page.locator('.calendar-grid .day-add').count() == 42)
    check('desktop sync status is visible', page.locator('#sync-status').evaluate("el => getComputedStyle(el).display !== 'none'"))
    page.screenshot(path='/mnt/data/dayframe-github-desktop-preview.png', full_page=True)
    # Date-specific quick add and task save.
    add = page.locator('.calendar-grid .day-add').first
    selected_date = add.get_attribute('data-event-date')
    add.click()
    page.wait_for_selector('#event-form')
    check('quick add preselects clicked date', page.locator('#event-form [name=date]').input_value() == selected_date)
    page.locator('#event-title').fill('Mobile sync test task')
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(x => x.title === 'Mobile sync test task')", timeout=7000)
    check('task save reaches Firestore adapter', True)
    # Profile photos now use a compressed Firestore profile document.
    icon = str(ROOT / 'icons' / 'icon-512.png')
    page.locator('#profile-upload').set_input_files(icon)
    page.wait_for_function("window.__mockDayframe.data.profile.has('avatar')", timeout=10000)
    page.wait_for_function("document.querySelector('#avatar-image').classList.contains('hidden') === false", timeout=5000)
    profile = page.evaluate("window.__mockDayframe.data.profile.get('avatar')")
    check('profile photo is stored in Firestore as a data URL', bool(profile and str(profile.get('dataUrl', '')).startswith('data:image/')))
    check('profile photo stays within compressed-size cap', bool(profile and profile.get('size', 10**9) <= 460000))
    check('profile photo does not call Firebase Storage', page.evaluate('window.__mockDayframe.storage.size') == 0)
    # Simulate Firestore refusing one avatar write: the phone/browser copy should remain queued and retry on tap.
    page.evaluate('window.__mockDayframe.failProfileOnce = true')
    page.locator('#profile-upload').set_input_files(icon)
    page.wait_for_function("document.querySelector('#sync-status').textContent.toLowerCase().includes('profile photo failed')", timeout=10000)
    check('profile photo remains queued locally when Firebase denies a write', page.evaluate("Boolean(window.__mockDayframe.idbRecords.get('dayframe-avatar-pending-v1-mock-user-1')?.value?.dataUrl)"))
    page.locator('#sync-status').click()
    page.wait_for_function("!window.__mockDayframe.idbRecords.has('dayframe-avatar-pending-v1-mock-user-1')", timeout=7000)
    check('queued profile photo retries and clears after successful cloud write', page.evaluate("window.__mockDayframe.data.profile.has('avatar') && !window.__mockDayframe.idbRecords.has('dayframe-avatar-pending-v1-mock-user-1')"))
    # Deliberately break localStorage then simulate one transient cloud write failure.
    page.evaluate('window.__mockDayframe.failLocalStorage = true')
    page.locator('[data-view="Tasks"]').click()
    page.locator('.page-heading [data-new-event="task"]').click()
    page.wait_for_selector('#event-form')
    page.locator('#event-title').fill('Recovery test')
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("document.querySelector('#sync-status').textContent.toLowerCase().includes('sync issue')", timeout=6000)
    check('localStorage failures do not crash saving and expose sync issue', 'sync issue' in page.locator('#sync-status').inner_text().lower())
    check('pending writes are durably queued in IndexedDB fallback', page.evaluate("Boolean(window.__mockDayframe.idbRecords.get('dayframe-pending-v1-mock-user-1')?.value?.some(x => x.data?.title === 'Recovery test'))"))
    page.evaluate("window.dispatchEvent(new Event('online'))")
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(x => x.title === 'Recovery test')", timeout=7000)
    check('queued item retries successfully after reconnection', True)
    check('no desktop JavaScript runtime errors', len(errors) == 0)

    # Phone layout and touch flows.
    context = browser.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True, device_scale_factor=2, service_workers='block')
    page = context.new_page()
    mobile_errors = []
    page.on('pageerror', lambda e: mobile_errors.append(str(e)))
    page.set_content(html, wait_until='domcontentloaded')
    page.wait_for_selector('#app:not(.hidden)', timeout=10000)
    page.wait_for_selector('.calendar-grid', timeout=10000)
    page.wait_for_timeout(200)
    check('mobile dashboard renders', page.locator('.calendar-grid').count() == 1)
    check('mobile sync status is visible', page.locator('#sync-status').evaluate("el => getComputedStyle(el).display !== 'none' && el.getBoundingClientRect().width > 0"))
    check('mobile layout has no horizontal page overflow', page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 1'))
    page.screenshot(path='/mnt/data/dayframe-github-mobile-preview.png', full_page=True)
    page.get_by_role('button', name='Show details').click()
    check('mobile Show details control opens details', page.locator('#details').evaluate("el => getComputedStyle(el).display !== 'none' && el.getBoundingClientRect().height > 0"))
    page.get_by_role('button', name='Hide date details').click()
    check('mobile Hide details control closes details', 'details-hidden' in (page.locator('#layout').get_attribute('class') or ''))
    page.locator('#mobile-menu').click()
    check('mobile navigation drawer opens', 'mobile-open' in (page.locator('#sidebar').get_attribute('class') or ''))
    page.locator('[data-view="Notes"]').click()
    check('mobile navigation closes after selection', 'mobile-open' not in (page.locator('#sidebar').get_attribute('class') or ''))
    page.evaluate('window.__mockDayframe.failLocalStorage = true')
    page.locator('[data-new-event="note"]').click()
    page.wait_for_selector('#event-form')
    page.locator('#event-title').fill('Mobile note saved')
    page.locator('#event-form [name=kind]').select_option('note')
    page.locator('#event-form button[type=submit]').click()
    page.wait_for_function("[...window.__mockDayframe.data.events.values()].some(x => x.title === 'Mobile note saved')", timeout=6000)
    check('mobile note saves to cloud adapter', True)
    check('mobile note uses IndexedDB queue when localStorage is unavailable', page.evaluate("Boolean(window.__mockDayframe.idbRecords.get('dayframe-pending-v1-mock-user-1'))"))
    check('no mobile JavaScript runtime errors', len(mobile_errors) == 0)
    browser.close()

for label, ok in RESULTS:
    print(('PASS' if ok else 'FAIL') + ' ' + label)
print(f'\n{sum(ok for _, ok in RESULTS)}/{len(RESULTS)} checks passed')
if any(not ok for _, ok in RESULTS):
    raise SystemExit(1)
