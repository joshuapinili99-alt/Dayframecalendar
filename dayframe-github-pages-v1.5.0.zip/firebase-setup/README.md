# Firebase setup for Dayframe v1.5.0

## 1. Deploy the Firestore rules

In Firebase Console, open **Firestore Database → Rules** and review `firestore.rules` from this folder. If this Firebase project is used only for Dayframe, you can replace the existing rules with this file and click **Publish**. If the project is shared with another app, merge the Dayframe match blocks into your existing rules instead of replacing unrelated rules. These rules restrict events, folders, and profile photos to the signed-in user's own documents. The profile rule limits avatar payload size to protect Firestore's document-size limit.

## 2. Profile photos no longer use Firebase Storage

Dayframe compresses a profile image to at most 440 KiB, converts it to a data URL, and stores it in `users/{uid}/profile/avatar`. This avoids the Cloud Storage dependency for profile photos. For iPhone HEIC/HEIF images, the app attempts conversion in the browser through a small external converter; if the conversion library cannot load, export the image as JPG/PNG and try again.

## 3. Event attachments still use Firebase Storage

If your app uses attachments, create/enable Cloud Storage and review `storage.rules` from this folder. If other applications share the same Storage bucket, merge the Dayframe path rule into the existing rules instead of replacing unrelated rules. **Current Firebase policy requires the Blaze pay-as-you-go plan for Cloud Storage**, even though usage may qualify for no-cost allowances depending on the bucket and usage. Set budget alerts and check the official policy before enabling billing:

- https://firebase.google.com/docs/storage/faqs-storage-changes-announced-sept-2024
- https://firebase.google.com/docs/storage/web/start

If you do not want to enable Cloud Storage billing, tasks, notes, meetings, calendar records, and compressed profile photos can still use Firestore, but attachment uploads will fail until Storage is available.

## 4. Authentication

In Firebase Console → Authentication:

- Enable Google sign-in and/or Email/Password.
- Add the exact GitHub Pages hostname to **Settings → Authorized domains**. For a site URL like `https://USERNAME.github.io/REPOSITORY/`, add only `USERNAME.github.io`.
- Do not put a protocol (`https://`) or path into Authorized domains.

## 5. Verify cloud sync on phone and desktop

1. Open the deployed HTTPS URL and sign in.
2. Create a small test task and wait for the status to show **Synced**.
3. Refresh the page. Verify the task remains.
4. Open the same account on a second device and verify the task appears there.
5. Upload a profile photo, wait for **Profile photo saved**, refresh, and verify it remains.
6. Test attachments only after Storage is configured and billing requirements are met.

The app keeps a browser-side recovery copy and a pending-write queue in IndexedDB as well as localStorage. This helps with reloads and spotty mobile connections, but a local copy is not the same thing as a confirmed cloud save. If the status shows a sync error, tap the status text to retry after correcting the Firebase issue.
