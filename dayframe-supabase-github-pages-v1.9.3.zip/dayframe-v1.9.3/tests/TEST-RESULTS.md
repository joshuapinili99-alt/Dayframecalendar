# Automated smoke-test results

PASS: retired backend references are absent from the active app
PASS: Supabase is the only database SDK loaded by the app
PASS: Supabase project URL is configured
PASS: exact REST endpoint from attached note is configured
PASS: Supabase JS client root URL is derived correctly from the REST endpoint
PASS: Supabase JS client is pinned to a specific CDN version
PASS: password recovery modal has a Supabase password-update flow
PASS: Supabase anon key is embedded with public-client configuration
PASS: desktop calendar renders
PASS: date-specific quick-add buttons render
PASS: visible syncing wording is removed
PASS: service worker cache version updated for this release
PASS: quick add preselects selected date
PASS: task persists to Supabase event table adapter
PASS: profile picture is saved as a compressed Supabase profile value
PASS: profile picture stays near the 440 KB compression target
PASS: profile photo does not upload to the attachment bucket
PASS: failed avatar cloud write remains queued in IndexedDB
PASS: queued profile photo retries and clears after simulated success
PASS: attachment uploads use Supabase Storage and private signed URLs
PASS: uploaded attachment object is kept in the simulated private bucket
PASS: offline/error path retains durable pending task queue when localStorage fails
PASS: pending task synchronizes after reconnection
PASS: checklist type and each checklist row persist in the database record
PASS: individual checklist toggle is saved to Supabase
PASS: calendar view uses 80 percent transform scale
PASS: desktop calendar shows all seven weekday columns without clipping
PASS: non-calendar views use 110 percent workspace zoom
PASS: Notes title and body autosave to the Supabase record
PASS: Notes can be pinned and pin state persists
PASS: Notes search filters the note list
PASS: due-date reminder preference persists with the planner item
PASS: due reminder permission is opt-in and reminder checker is included
PASS: realtime external changes update the UI
PASS: slow stale cloud response cannot overwrite a newly saved record
PASS: periodic database polling refreshes remote changes without Realtime
PASS: email/password login returns through Supabase Auth
PASS: mobile view has no horizontal page overflow
PASS: mobile layout hides sync status wording
PASS: mobile navigation toggle exists
PASS: remote desktop task appears in the mobile task list
PASS: mobile non-calendar view keeps 110 percent zoom without horizontal overflow
PASS: mobile calendar uses 80 percent transform scale without page overflow
PASS: mobile calendar shows all seven weekday columns without clipping
PASS: mobile Notes list/editor layout remains within viewport
PASS: mobile Notes editor opens with a back-to-list control
PASS: mobile Notes list view returns correctly
PASS: no page-level JavaScript runtime errors

**Result: 48/48 passed.**

Tests use a simulated Supabase client and do not verify the live project's schema, RLS policies, OAuth provider configuration, storage policies, or actual cross-device network behavior.
