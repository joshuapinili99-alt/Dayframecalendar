-- Dayframe v1.9.3: repair missing public.dayframe_events / stale PostgREST schema cache
-- Run in Supabase Dashboard -> SQL Editor using the project owner role.
-- This is safe to re-run. It creates the required events table if it is absent,
-- enables per-user RLS, grants authenticated access, and reloads PostgREST's schema cache.

begin;

create table if not exists public.dayframe_events (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

alter table public.dayframe_events enable row level security;
revoke all on table public.dayframe_events from public, anon;
grant select, insert, update, delete on table public.dayframe_events to authenticated;

drop policy if exists "Dayframe users own their events" on public.dayframe_events;
create policy "Dayframe users own their events"
  on public.dayframe_events for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

alter table public.dayframe_events replica identity full;
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin
      alter publication supabase_realtime add table public.dayframe_events;
    exception when duplicate_object then null;
    end;
  end if;
end $$;

notify pgrst, 'reload schema';
commit;

-- Verify the table exists. This should return public.dayframe_events.
select table_schema, table_name
from information_schema.tables
where table_schema = 'public' and table_name = 'dayframe_events';
