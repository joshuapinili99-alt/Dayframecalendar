-- Dayframe v1.9.3 Supabase-only setup
-- Run this script in Supabase Dashboard -> SQL Editor using the project owner role.
-- All planner rows are user-scoped and protected by Row Level Security (RLS).

create table if not exists public.dayframe_events (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.dayframe_folders (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

create table if not exists public.dayframe_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  avatar_data_url text,
  updated_at timestamptz not null default now()
);

alter table public.dayframe_events enable row level security;
alter table public.dayframe_folders enable row level security;
alter table public.dayframe_profiles enable row level security;

revoke all on table public.dayframe_events from public, anon;
revoke all on table public.dayframe_folders from public, anon;
revoke all on table public.dayframe_profiles from public, anon;
grant select, insert, update, delete on table public.dayframe_events to authenticated;
grant select, insert, update, delete on table public.dayframe_folders to authenticated;
grant select, insert, update on table public.dayframe_profiles to authenticated;

drop policy if exists "Dayframe users own their events" on public.dayframe_events;
create policy "Dayframe users own their events"
  on public.dayframe_events for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Dayframe users own their folders" on public.dayframe_folders;
create policy "Dayframe users own their folders"
  on public.dayframe_folders for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Dayframe users own their profiles" on public.dayframe_profiles;
create policy "Dayframe users own their profiles"
  on public.dayframe_profiles for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

-- Use a private bucket. The app creates 7-day signed URLs and refreshes them
-- when the app is opened or returned to the foreground.
insert into storage.buckets (id, name, public, file_size_limit)
values ('dayframe-attachments', 'dayframe-attachments', false, 10485760)
on conflict (id) do update
set public = false, file_size_limit = 10485760;

drop policy if exists "Dayframe users read own attachments" on storage.objects;
create policy "Dayframe users read own attachments"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  );

drop policy if exists "Dayframe users upload own attachments" on storage.objects;
create policy "Dayframe users upload own attachments"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  );

drop policy if exists "Dayframe users update own attachments" on storage.objects;
create policy "Dayframe users update own attachments"
  on storage.objects for update to authenticated
  using (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  )
  with check (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  );

drop policy if exists "Dayframe users delete own attachments" on storage.objects;
create policy "Dayframe users delete own attachments"
  on storage.objects for delete to authenticated
  using (
    bucket_id = 'dayframe-attachments'
    and (storage.foldername(name))[1] = 'users'
    and (storage.foldername(name))[2] = (select auth.uid()::text)
  );

-- Enable Realtime for cross-device updates. Safe to rerun if these tables
-- are already members of the publication.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin
      alter publication supabase_realtime add table public.dayframe_events;
    exception when duplicate_object then null;
    end;
    begin
      alter publication supabase_realtime add table public.dayframe_folders;
    exception when duplicate_object then null;
    end;
    begin
      alter publication supabase_realtime add table public.dayframe_profiles;
    exception when duplicate_object then null;
    end;
  else
    raise notice 'Realtime publication supabase_realtime was not found. Dayframe will use its 12-second refresh fallback; to enable instant updates, enable Realtime for dayframe_events, dayframe_folders, and dayframe_profiles in the Supabase Dashboard.';
  end if;
end $$;

alter table public.dayframe_events replica identity full;
alter table public.dayframe_folders replica identity full;
alter table public.dayframe_profiles replica identity full;

-- Verify the Realtime tables are enabled (should return three rows).
select schemaname, tablename
from pg_publication_tables
where pubname = 'supabase_realtime'
  and schemaname = 'public'
  and tablename in ('dayframe_events', 'dayframe_folders', 'dayframe_profiles')
order by tablename;


-- Refresh PostgREST's schema cache so newly created tables are immediately discoverable.
notify pgrst, 'reload schema';
