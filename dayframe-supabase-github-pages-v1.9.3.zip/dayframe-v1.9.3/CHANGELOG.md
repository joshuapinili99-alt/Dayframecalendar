# Changelog

## v1.9.3
- Added a specific user-facing diagnosis for missing Dayframe tables in the Supabase/PostgREST schema cache.
- Added `NOTIFY pgrst, 'reload schema'` at the end of the full Supabase setup SQL.
- Added an idempotent targeted repair script for `public.dayframe_events`, including per-user RLS, grants, Realtime membership where available, and schema-cache reload.
- Bumped the service-worker cache so updated diagnostics and setup-linked app code are loaded after deployment.

The app code cannot create a missing table in the user's live database automatically. Run the SQL included in this package against the same Supabase project configured in `index.html`.
