# Dayframe v1.14.3 Release Notes

## Deletion reliability

- Replaced `window.confirm()` prompts for item and folder deletion with an app-native, responsive confirmation dialog.
- The edit modal remains available if a user cancels deletion.
- Confirmed deletions update the local view immediately and continue to use the pending-delete recovery mechanism for Firestore synchronization.

## One-tap checklists

- The **New checklist** button immediately creates a checklist.
- Focus moves to the inline **Add a checklist item** field, so the user can start entering steps immediately.
- Steps are saved locally first and synchronized through the existing Firebase autosave path.

## Due reminders

- In-app reminders work while Dayframe is open without requiring notification permission.
- Reminder popup cards use the app's soft color palette and provide **Open item** and **Dismiss** actions.
- New and legacy items with no saved reminder preference default to 10 minutes before their start time (or 9:00 AM when no time is set). Select **No reminder** to disable. Date-only items without a start time use 9:00 AM as the reminder time; items created after that assumed time are not immediately nagged for an already-past reminder.
- Browser/system notifications remain optional and are emitted when permission has been granted. These reminders require the app to be open; this static GitHub Pages app does not implement background push delivery when closed.

## More efficient image export

- PNG canvas resolution adapts to estimated device memory and has an 8-million-pixel standard cap (4.5 million pixels on devices reporting 4 GB RAM or less).
- Compatible mobile browsers can open the native share sheet to save or share the image; other environments use a direct download fallback.

## Verification

- Release-specific static regression checks cover deletion flow, inline checklist creation, due reminder configuration and UI, and bounded image export.
- JavaScript syntax and the complete existing automated suite were run for the packaged release. Live Firebase and real-device behavior still depends on the deployed Firebase project, browser, and device.
