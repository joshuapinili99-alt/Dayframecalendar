# Firebase Admin SDK integration (server-side only)

The attached `firebase-admin` snippet has been integrated as `admin/firebase-admin-check.cjs`. It is deliberately kept out of the browser app and out of the GitHub Pages deploy artifact. Firebase Admin SDK has privileged server access and must never be bundled into `index.html` or exposed to users.

## What this does

- Initializes Firebase Admin for project `my-personal-calendar-a6ef3`.
- Uses `credential.cert(serviceAccount)` when a service-account file path is supplied, matching the intent of the attached snippet.
- Uses Application Default Credentials when running on a supported Google Cloud server without a key file.
- Runs a non-destructive Firestore connectivity check and does not print or edit user records.

**Important:** This helper is an administrative connectivity check. It does not itself make the browser app sync; Dayframe's desktop/mobile synchronization still uses the Firebase Web SDK and the Firestore real-time listeners in `index.html`. Admin SDK requests bypass Firestore Security Rules, so do not use it as a replacement for the app's per-user rules.

## Run locally (Windows PowerShell)

1. In Firebase Console, open **Project settings → Service accounts** and create a private service-account key only if you need local administrative access. Store the JSON outside the repository, in a folder only you can access.
2. Install Node.js 20 or later.
3. From the repository root, run:

   ```powershell
   cd admin
   npm install
   $env:FIREBASE_PROJECT_ID = "my-personal-calendar-a6ef3"
   $env:DAYFRAME_SERVICE_ACCOUNT_PATH = "C:\secure\path\serviceAccountKey.json"
   npm run check
   ```

For Google Cloud runtimes with Application Default Credentials, omit `DAYFRAME_SERVICE_ACCOUNT_PATH` and configure the runtime's service identity with the minimum required permissions.

## Secret handling

- Never commit the service-account JSON, private key, `.env` file, or any generated credential to GitHub.
- The repository `.gitignore` excludes common service-account key names and environment files.
- If a service-account key has ever been committed or shared publicly, revoke it immediately in Google Cloud/Firebase and create a new one.
- Do not put service-account values in `index.html`, client-side JavaScript, GitHub Pages, screenshots, or chat messages.

## If mobile still does not sync

A successful Admin SDK check only verifies server-side credentials and Firestore access. It does not prove that the phone and desktop are signed in as the same Firebase UID, that the web app's client rules are published, or that the browser's client SDK has no listener errors. Check Dayframe's sync-status control on both devices and compare the account reference. Both devices should use the same Login ID for the same planner, while different people should use separate accounts.
