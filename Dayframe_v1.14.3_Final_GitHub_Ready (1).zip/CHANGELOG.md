# Dayframe Changelog

## v1.14.3 · Reliable actions and polished daily workflow

- Replaced native browser confirmation prompts for deleting planner items and folders with a consistent in-app dialog that works across desktop and mobile; cancelling preserves the active editor.
- Checklist creation is now one tap from the Checklist view. It immediately creates a checklist and focuses an inline field for adding the first step; steps can be added without reopening the full editor.
- Added stylish in-app due reminders that work while Dayframe is open even when operating-system notifications are unavailable or denied. Items default to 10 minutes before the due time; reminders can be disabled or changed per item.
- Calendar PNG export now adapts canvas resolution to the estimated device memory and caps total image pixels to reduce memory pressure on phones. Supported devices can share the image directly; other browsers use the download fallback.
- Added release-specific regression checks for delete actions, checklist creation, due reminders, image export limits, and responsive presentation.

## Firebase Firestore rule deployment configuration (v1.14.2 package update)

- Added the supplied owner-only rule to the root `firestore.rules` file.
- Added `firebase.json` and `.firebaserc` so the Firebase CLI can deploy the Firestore rules to the configured project.
- Added a CI regression check for UID-based access restrictions and the rules deployment configuration.
- Kept Firestore rules deployment separate from GitHub Pages; no privileged Firebase credentials are used in the Pages workflow.

## v1.14.2 · Mobile-first UI and quiet Firebase auto-sync

- Mobile screens now open into Agenda view, making task titles and details readable and actionable without the compressed month grid.
- Tightened responsive overflow, headers, toolbar wrapping, note panels, and touch targets at phone widths.
- Routine task saves no longer trigger success popups or visible per-write loading text. Changes are cached locally immediately and sent to Firebase in the background; transient cloud failures retry quietly with bounded backoff.
- Notes continue to auto-save without blocking typing; the UI distinguishes local save from Firebase acknowledgement.
- Strengthened account-switch guards and added a visible warning that sharing the same Login ID shares the same planner. Separate users should use separate accounts.

## v1.14.1 · Durable offline delete recovery

- Persists pending delete tombstones to localStorage with an IndexedDB backup, so failed/offline deletions survive refreshes and browser restarts.
- Restores pending deletes before cloud reconciliation, preventing stale local or Firebase snapshots from resurrecting deleted events and folders.
- Retries saved delete operations on startup, including after an initial Firestore read failure.
- Removes a duplicate in-flight cleanup statement and adds dedicated automated coverage for pending-delete persistence.

## v1.14.0 · Cross-device sync recovery

- Fixed startup reconciliation that could ignore desktop-local tasks when some cloud records already existed.
- Merges local cache and Firestore records by ID and timestamps, uploads local-only/newer local records, and preserves newer cloud records.
- Live Firestore listeners preserve pending local edits and deletions instead of allowing an older snapshot to hide them.
- Failed cloud writes remain locally available and retry on reconnection or when the app becomes visible.
- Selects the freshest complete browser cache snapshot to avoid restoring stale IndexedDB data after a deletion.
- The sync-status message helps identify which Login ID is active, so desktop and mobile accounts can be compared.
- Adds automated regression tests for partial-cloud recovery and reconciliation behavior.

## v1.13.0 · Performance and mobile UX

- Faster calendar first paint and grouped event-by-date rendering.
- Mobile layout hardening across calendar, tasks, meetings, checklists, folders, notes, attachments, details, and forms.
- Disabled mobile pinch/double-tap zoom as requested while preserving normal scrolling and taps.
- Added high-resolution PNG export for Month, Week, and Agenda calendar views.
- Added a consistent Dayframe logo, refreshed app icons, favicon, and service-worker cache.

## v1.12.0 · Private Login ID

- Added a private Login ID and password flow for new users while retaining legacy email-based sign-in.
- Enabled persistent Firestore caching and multi-tab coordination where supported.
- Added synchronized dark-mode and workspace-background preferences.

## v1.11.0 · Firebase integration

- Connected Firebase Authentication, Cloud Firestore planner records, and Firebase Storage uploads.
- Added owner-scoped Firestore and Storage security rules and GitHub Pages deployment documentation.

## Firebase Admin SDK helper integration (v1.14.2 package add-on)
- Integrated the provided `firebase-admin` initialization pattern into `admin/firebase-admin-check.cjs` as a server-side-only connectivity checker.
- Supports a service-account JSON supplied by environment path or Application Default Credentials on supported Google Cloud runtimes.
- Added `FIREBASE-ADMIN-SETUP.md` and a separate `admin/package.json` so the Admin SDK dependency is not mixed into the static browser app.
- Added Git ignore rules for service-account JSON files and environment secret files; no private key is included in this archive.
- Added CI/static integration checks. The GitHub Pages workflow copies only static app assets, not the Admin SDK helper.
- This helper verifies admin-side Firestore connectivity; it does not replace the client SDK, published Firestore rules, or live cross-device testing.
