# Dayframe v1.14.0 release notes

## Fixes

- Fixed incomplete reconciliation when the cloud had some records but not every desktop-local task.
- Added local-vs-cloud merging by record ID and update timestamps.
- Uploads desktop-local items and newer local edits to Firestore on sign-in.
- Prevents live snapshots from hiding pending local writes/deletes.
- Keeps failed writes in local recovery state and retries on reconnection/visibility.
- Chooses the freshest complete LocalStorage/IndexedDB snapshot to reduce stale cache restoration.
- Improves account identity information in the sync-status message to help diagnose mismatched Login IDs.

## Deployment and recovery steps

1. Upload the entire ZIP to the root of the same GitHub repository, including `.github/workflows/deploy-pages.yml`.
2. Wait for the GitHub Pages workflow to finish and open the deployed app on the original desktop browser.
3. Sign in with the same Firebase Login ID used on mobile while online. If local-only items exist, the new app submits them to Firestore. Wait until the sync status returns to up-to-date and no recovery items remain.
4. Refresh the app on mobile and verify the exact same Login ID is being used.
5. If items still do not appear, check the sync status and Firebase Console for Firestore permission-denied/network errors.

Static tests verify merge logic and source-level integration. Live Firebase synchronization still depends on the configured Firebase services and a successful real-device test.
