# Dayframe v1.14.1 release notes

## Fixes

- Persists offline or failed event/folder deletions in an account-scoped recovery journal.
- Uses localStorage for immediate persistence and IndexedDB as a fallback when localStorage is blocked.
- Restores tombstones before cloud reconciliation and filters deleted records from stale local and Firestore snapshots.
- Retries pending deletes after sign-in, including after an initial Firestore read failure.
- Preserves immediate calendar rendering while the IndexedDB fallback is checked.
- Adds a dedicated behavior test for pending-delete persistence and clears tombstones after a successful cloud acknowledgement.

## Deployment

Upload the full ZIP to the root of your GitHub repository, including `.github/workflows/deploy-pages.yml`. In GitHub repository settings, select **Settings → Pages → GitHub Actions**. Complete the Firebase requirements described in `FIREBASE-SETUP.md` before testing account creation and cloud sync.

The release runs static regression checks, two sync behavior tests, and a JavaScript module syntax check in GitHub Actions. These tests cannot confirm that Firebase services and production rules are enabled in the target project, so verify live sign-in and device-to-device sync after deployment.
