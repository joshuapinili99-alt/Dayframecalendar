# Dayframe v1.13.0

- Calendar paints immediately from the local per-user cache while Firebase completes its fetch.
- Date-grouped event rendering reduces repeated scans for large planners.
- Responsive layout fixes for mobile headings, calendar controls, task rows, folders, notes, modals, attachments, and detail panels.
- Mobile pinch and double-tap zoom disabled; ordinary scrolling and taps remain enabled.
- Current Month, Week, or Agenda view can be exported to a high-resolution PNG image.
- New cohesive Dayframe logo and refreshed favicon, PWA, and Apple touch icons.

Cloud data remains in Firebase. Deploy the complete ZIP to GitHub Pages and test saving/syncing with the same account on desktop and mobile.
