'use strict';

// Server-side only. Never import this file into index.html or ship a service-account
// JSON private key to GitHub Pages or a user's browser.
const admin = require('firebase-admin');
const fs = require('node:fs');
const path = require('node:path');

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'my-personal-calendar-a6ef3';
const SERVICE_ACCOUNT_PATH = process.env.DAYFRAME_SERVICE_ACCOUNT_PATH
  || process.env.GOOGLE_APPLICATION_CREDENTIALS;
const APP_NAME = 'dayframe-admin-check';

function buildCredential() {
  if (SERVICE_ACCOUNT_PATH) {
    const fullPath = path.resolve(SERVICE_ACCOUNT_PATH);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`Service-account file was not found at the configured path: ${fullPath}`);
    }

    // This follows the supplied snippet's credential.cert(serviceAccount) pattern,
    // but reads the key from a local/server environment variable, not from the ZIP.
    const serviceAccount = require(fullPath);
    if (!serviceAccount || typeof serviceAccount !== 'object' || !serviceAccount.project_id) {
      throw new Error('The configured service-account JSON is invalid or missing project_id.');
    }
    if (serviceAccount.project_id !== PROJECT_ID) {
      throw new Error(`Service-account project (${serviceAccount.project_id}) does not match configured project (${PROJECT_ID}).`);
    }
    return admin.credential.cert(serviceAccount);
  }

  // On supported Google Cloud runtimes, Application Default Credentials avoid
  // storing a private key in the repository.
  return admin.credential.applicationDefault();
}

function initializeAdmin() {
  const existing = admin.apps.find((app) => app && app.name === APP_NAME);
  if (existing) return existing;

  return admin.initializeApp({
    credential: buildCredential(),
    projectId: PROJECT_ID
  }, APP_NAME);
}

async function main() {
  let app;
  try {
    app = initializeAdmin();
    const db = admin.firestore(app);

    // A metadata-level listing verifies authenticated Firestore access without
    // creating, modifying, deleting, or printing any user records.
    const collections = await db.listCollections();
    console.log(`Firebase Admin SDK connected to project: ${PROJECT_ID}`);
    console.log(`Firestore connectivity check passed. Top-level collections found: ${collections.length}.`);
    console.log('No user data was created, read individually, modified, or deleted by this check.');
  } catch (error) {
    console.error('Firebase Admin SDK connectivity check failed.');
    console.error(error && error.message ? error.message : String(error));
    if (!SERVICE_ACCOUNT_PATH) {
      console.error('For local use, set DAYFRAME_SERVICE_ACCOUNT_PATH to the absolute path of the service-account JSON, or configure Application Default Credentials.');
    }
    process.exitCode = 1;
  } finally {
    if (app) {
      try { await app.delete(); } catch (_) { /* Preserve the original check result. */ }
    }
  }
}

main();
