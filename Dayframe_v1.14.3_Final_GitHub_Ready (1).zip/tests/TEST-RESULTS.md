# Dayframe v1.14.3 verification

- General application smoke checks: 33/33 passed.
- Admin SDK package integration checks: 9/9 passed.
- Firestore security-rule checks: 8/8 passed.
- Inherited mobile/autosave/account-isolation regression checks: 17/17 passed.
- v1.14.3 interaction regression checks: 21/21 passed.
- Sync reconciliation behavior test: passed. Verifies local-only tasks/folders, newer local edits, newer cloud records, legacy records without update timestamps, and pending edits/deletes.
- Cloud retry scheduler behavior test: passed. Verifies bounded backoff, active-account scoping, and timer cleanup.
- Pending-delete journal behavior test: passed. Verifies tombstone persistence, account-scoped restoration, exclusion of normal edits, and cleanup after acknowledgement.
- JavaScript module syntax check: passed with Node.js `--check`.
- ZIP integrity: passed on the final release archive.

These checks verify source wiring, static behavior, the existing reconciliation/retry logic, and packaging. They do not prove that Firebase is enabled or that real-device behavior is flawless. The release still needs live testing on an actual phone and desktop against the configured Firebase project. Due reminders work while Dayframe is open; when the page is hidden they can use operating-system notifications only if the browser grants permission. This static GitHub Pages app does not implement push reminders when completely closed.
