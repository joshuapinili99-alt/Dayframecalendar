"""Static tests for safe Firebase Admin SDK integration."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
admin_script = ROOT / 'admin/firebase-admin-check.cjs'
admin_package = ROOT / 'admin/package.json'
setup_doc = ROOT / 'FIREBASE-ADMIN-SETUP.md'
gitignore = (ROOT / '.gitignore').read_text(encoding='utf-8')
workflow = (ROOT / '.github/workflows/deploy-pages.yml').read_text(encoding='utf-8')
html = (ROOT / 'index.html').read_text(encoding='utf-8')
script = admin_script.read_text(encoding='utf-8') if admin_script.exists() else ''
pkg = admin_package.read_text(encoding='utf-8') if admin_package.exists() else ''
doc = setup_doc.read_text(encoding='utf-8') if setup_doc.exists() else ''
checks = []
def check(name, ok): checks.append((name, bool(ok)))

check('Admin SDK helper exists outside the browser entry point', admin_script.exists() and 'firebase-admin' in script and 'firebase-admin' not in html)
check('Attached cert(serviceAccount) approach is supported through an environment-specified key path', 'admin.credential.cert(serviceAccount)' in script and 'DAYFRAME_SERVICE_ACCOUNT_PATH' in script)
check('Application Default Credentials are supported for server runtimes', 'admin.credential.applicationDefault()' in script)
check('Admin connectivity check makes no Firestore writes', 'db.listCollections()' in script and 'db.doc(' not in script and 'db.collection(' not in script and 'db.delete' not in script)
check('Admin SDK dependency is declared in its own package', admin_package.exists() and '"firebase-admin"' in pkg and '"private": true' in pkg)
check('Common service-account key names and environment files are ignored by Git', 'serviceAccountKey.json' in gitignore and '*-firebase-adminsdk-*.json' in gitignore and '.env.*' in gitignore)
check('Setup docs warn not to deploy a service key or use Admin SDK in browser', 'never be bundled into `index.html`' in doc and 'Never commit the service-account JSON' in doc)
check('GitHub Pages workflow runs the static integration check', 'python tests/test_admin_sdk_integration.py' in workflow)
check('GitHub Pages workflow copies only static app assets, not Admin SDK helpers', 'cp index.html manifest.webmanifest sw.js .nojekyll _site/' in workflow and 'cp -R admin' not in workflow)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} Admin SDK integration checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed))
    sys.exit(1)
