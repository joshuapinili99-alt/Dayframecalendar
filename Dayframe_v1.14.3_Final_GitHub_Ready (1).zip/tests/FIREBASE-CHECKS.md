# Firebase integration checks

Static checks to complete before publishing:
- `index.html` is an ES module and imports Firebase App, Auth, Firestore, and Storage SDKs.
- The app references only the provided Firebase project configuration.
- Calendar items/folders are stored in per-user Firestore collections and synchronized with `onSnapshot`.
- Profile photos and attachments are uploaded to per-user Firebase Storage paths.
- `firestore.rules` and `storage.rules` limit access to the authenticated matching UID.

Live sign-in/storage tests require Firebase Authentication, Firestore, Storage, and rules to be enabled in the Firebase Console.
