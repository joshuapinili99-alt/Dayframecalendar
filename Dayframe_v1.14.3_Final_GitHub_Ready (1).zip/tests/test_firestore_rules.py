"""Static checks for the user-owned Firestore security rules and deploy config."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
rules_path = ROOT / "firestore.rules"
config_path = ROOT / "firebase.json"
project_path = ROOT / ".firebaserc"
workflow_path = ROOT / ".github/workflows/deploy-pages.yml"
rules = rules_path.read_text(encoding="utf-8") if rules_path.exists() else ""
config = json.loads(config_path.read_text(encoding="utf-8")) if config_path.exists() else {}
project = json.loads(project_path.read_text(encoding="utf-8")) if project_path.exists() else {}
workflow = workflow_path.read_text(encoding="utf-8") if workflow_path.exists() else ""
checks = [
    ("Firestore rules use rules version 2", "rules_version = '2';" in rules),
    ("Rules apply under the users/{userId} document tree", "match /users/{userId}/{document=**}" in rules),
    ("Unauthenticated access is denied", "request.auth != null" in rules),
    ("Only the matching authenticated UID can read and write", "request.auth.uid == userId" in rules and "allow read, write:" in rules),
    ("Firebase CLI config points to firestore.rules", config.get("firestore", {}).get("rules") == "firestore.rules"),
    ("Default Firebase project matches the web app project", project.get("projects", {}).get("default") == "my-personal-calendar-a6ef3"),
    ("GitHub Pages deployment validates Firestore rules", "python tests/test_firestore_rules.py" in workflow),
    ("Static deployment does not deploy rules with privileged credentials", "firebase deploy" not in workflow.lower()),
]
for name, passed in checks:
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
failed = [name for name, passed in checks if not passed]
print(f"\n{len(checks) - len(failed)}/{len(checks)} Firestore rule checks passed")
if failed:
    print("Failed checks: " + "; ".join(failed))
    sys.exit(1)
