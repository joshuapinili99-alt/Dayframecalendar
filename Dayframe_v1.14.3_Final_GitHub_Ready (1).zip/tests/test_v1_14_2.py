"""Regression checks for Dayframe v1.14.2 mobile UX, quiet autosave, and account scoping."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
sw = (ROOT / 'sw.js').read_text(encoding='utf-8')
workflow = (ROOT / '.github/workflows/deploy-pages.yml').read_text(encoding='utf-8')
rules = (ROOT / 'firestore.rules').read_text(encoding='utf-8')
checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

check('HTML and service worker share current v1.14.3 release marker', '<meta name="dayframe-version" content="1.14.3">' in html and "const VERSION='1.14.3'" in sw and 'content="1.14.3"' in workflow)
check('Phone viewport opens the full Tasks list and desktop opens Calendar', "view:window.matchMedia('(max-width:760px)').matches?'Tasks':'Calendar'" in html and "mode:window.matchMedia('(max-width:760px)').matches?'Agenda':'Month'" in html)
check('Mobile Tasks view lists all open tasks and Agenda is still available', "if(state.mode==='Agenda')" in html and "Tasks:{title:'To-do lists',description:'Every open task" in html and 'entryRow' in html)
check('Cloud startup does not wait for getDocs before attaching listeners', 'getDocs(' not in html and 'startCloudListeners(user);retryPendingCloudRecovery(user);' in html)
check('Cache-only Firebase snapshots are never used to trigger recovery uploads', "const fromCache=!!snapshot.metadata?.fromCache" in html and "if(!fromCache)queueCloudRecoveryWrites('events',reconciled.toUpload)" in html and "if(!fromCache)queueCloudRecoveryWrites('folders',reconciled.toUpload)" in html)
check('Mobile layout includes overflow and touch target hardening', 'Dayframe v1.14.2: mobile-first agenda and touch-safe layouts.' in html and 'touch-action:manipulation' in html and 'grid-template-columns:repeat(7,minmax(0,1fr))' in html)
check('Planner local cache is keyed to signed-in Firebase UID', 'function userKey(kind,userId=state.user?.uid){return userId?`dayframe-${kind}-v1-${userId}`:null}' in html)
check('Firestore collections are scoped to the active UID', "collection(firebaseDb,'users',uidValue,'events')" in html and "collection(firebaseDb,'users',uidValue,'folders')" in html)
check('Firestore rules prevent cross-account access', 'request.auth.uid == userId' in rules)
check('Same-login data sharing is explained in the UI', 'anyone who shares this Login ID and password can see the same planner' in html and 'separate account' in html.lower())
check('Account-scoped state is cleared on sign-out and account changes', 'cloudAuthUid=null;state.events=[];state.folders=[]' in html and 'state.selectedNoteId=null' in html)
check('Cloud writes are stopped when the active session changes during local persistence', 'if(state.user?.uid!==userId)return;' in html)
check('Successful routine event saves do not show save-success toasts', "notify('Saved and syncing to Firebase.')" not in html and 'function saveEvent(ev)' in html)
check('Per-write visible loading status is not shown for ordinary cloud record writes', "updateSyncStatus('Saving changes','busy')" not in html)
check('Transient Firebase errors retry automatically with bounded backoff', 'function scheduleCloudRetry(user=state.user)' in html and 'Math.min(30000,1000*(2**Math.min(state.cloudRetryAttempts,5)))' in html and "updateSyncStatus('Cloud retry queued','busy')" in html)
check('Notes autosave locally while typing and explicitly reports cloud acknowledgement', 'Saved locally · syncing quietly' in html and 'Auto-save queued' in html and "noteStatus.textContent='Saved to Firebase'" in html)
check('GitHub Actions runs this release-specific regression suite', 'python tests/test_v1_14_2.py' in workflow)

failed = [name for name, condition in checks if not condition]
for name, condition in checks:
    print(f"{'PASS' if condition else 'FAIL'}: {name}")
print(f"\n{len(checks)-len(failed)}/{len(checks)} v1.14.3 inherited regression checks passed")
if failed:
    print('Failed checks: ' + '; '.join(failed))
    sys.exit(1)
