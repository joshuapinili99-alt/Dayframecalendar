"""Behavior tests for Dayframe's bounded background retry scheduler."""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
node = shutil.which('node')
if not node:
    print('SKIP: Node.js is not installed; cloud retry scheduler behavior was not executed')
    sys.exit(0)

match = re.search(r'(function clearCloudRetry\(\).*?)(?=\nfunction retryPendingCloudRecovery)', html, re.S)
if not match:
    raise SystemExit('FAIL: Could not extract cloud retry scheduler functions')
funcs = match.group(1)
script = f'''
const assert = require('node:assert/strict');
const timers = new Map();
let nextTimer = 1;
global.setTimeout = (fn, delay) => {{ const id=nextTimer++; timers.set(id, {{fn,delay}}); return id; }};
global.clearTimeout = id => timers.delete(id);
Object.defineProperty(global, 'navigator', {{value:{{onLine:true}}, configurable:true}});
const state = {{user:{{uid:'account-a'}},cloudRetryTimer:null,cloudRetryAttempts:0}};
let retries = 0;
function retryPendingCloudRecovery(user) {{ assert.equal(user.uid, state.user.uid); retries++; }}
{funcs}
function runNext() {{
 const first=[...timers.entries()][0]; assert.ok(first, 'a retry timer should be scheduled');
 timers.delete(first[0]); first[1].fn(); return first[1].delay;
}}
scheduleCloudRetry(state.user);
assert.equal([...timers.values()][0].delay,1000,'first retry waits one second');
assert.equal(runNext(),1000); assert.equal(retries,1);
scheduleCloudRetry(state.user);
assert.equal([...timers.values()][0].delay,2000,'second retry uses backoff');
assert.equal(runNext(),2000); assert.equal(retries,2);
const attemptsBefore=state.cloudRetryAttempts;
scheduleCloudRetry({{uid:'account-b'}});
assert.equal(timers.size,0,'a stale account cannot schedule work for the active session');
assert.equal(state.cloudRetryAttempts,attemptsBefore);
scheduleCloudRetry(state.user);
clearCloudRetry();
assert.equal(timers.size,0,'clearing session retries cancels the timer');
assert.equal(state.cloudRetryAttempts,0,'clearing session retries resets backoff');
console.log('PASS: transient Firebase retries use bounded backoff, retry the active account only, and clear on reset');
'''
result = subprocess.run([node, '-e', script], capture_output=True, text=True)
if result.returncode:
    print(result.stdout, end='')
    print(result.stderr, end='')
    print('FAIL: cloud retry scheduler behavior')
    sys.exit(result.returncode)
print(result.stdout, end='')
