"""Behavior tests for the durable delete journal used by Dayframe cloud sync."""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
node = shutil.which('node')
if not node:
    print('SKIP: Node.js is not installed; pending-delete persistence was not executed')
    sys.exit(0)

def extract(start, end):
    match = re.search(re.escape(start) + r'(.*?)' + re.escape(end), html, re.S)
    if not match:
        raise SystemExit(f'FAIL: Could not extract {start}')
    return start + match.group(1)

key_fn = extract('function pendingDeleteStorageKey(userId){', '\nfunction pendingDeleteEntries')
entries_fn = extract('function pendingDeleteEntries(recovery=state.cloudRecovery){', '\nfunction persistPendingDeletes')
persist_fn = extract('function persistPendingDeletes(userId=state.user?.uid){', '\nfunction applyPendingDeleteEntries')
apply_fn = extract('function applyPendingDeleteEntries(userId,entries){', '\nfunction restorePendingDeletesFromLocalStorage')
local_restore_fn = extract('function restorePendingDeletesFromLocalStorage(userId){', '\nasync function restorePendingDeletesFromIndexedDb')
idb_restore_fn = extract('async function restorePendingDeletesFromIndexedDb(userId){', '\nfunction filterPendingDeletedItems')
script = f'''
const assert = require('node:assert/strict');
const backing = new Map();
let denyLocalStorageWrites = false;
const memoryStorage = {{
  getItem(key) {{ return backing.has(key) ? backing.get(key) : null; }},
  setItem(key, value) {{ if (denyLocalStorageWrites) throw new Error('storage is blocked'); backing.set(key, String(value)); }},
  removeItem(key) {{ backing.delete(key); }}
}};
global.localStorage = memoryStorage;
const idb = new Map();
async function persistIdb(key, value) {{ idb.set(key, structuredClone(value)); return true; }}
async function idbGet(key) {{ return idb.has(key) ? structuredClone(idb.get(key)) : undefined; }}
const state = {{user:{{uid:'account-1'}},cloudRecovery:{{events:new Map(),folders:new Map()}}}};
{key_fn}
{entries_fn}
{persist_fn}
{apply_fn}
{local_restore_fn}
{idb_restore_fn}
(async()=>{{
  state.cloudRecovery.events.set('deleted-event', null);
  state.cloudRecovery.events.set('pending-edit', {{id:'pending-edit', title:'keep me'}});
  state.cloudRecovery.folders.set('deleted-folder', null);
  persistPendingDeletes('account-1');
  const key = pendingDeleteStorageKey('account-1');
  const stored = JSON.parse(localStorage.getItem(key));
  assert.deepEqual(stored, [{{collection:'events',id:'deleted-event'}},{{collection:'folders',id:'deleted-folder'}}]);
  await Promise.resolve();
  state.cloudRecovery = {{events:new Map(),folders:new Map()}};
  assert.equal(restorePendingDeletesFromLocalStorage('account-1'), true); 
  assert.equal(state.cloudRecovery.events.get('deleted-event'), null);
  assert.equal(state.cloudRecovery.folders.get('deleted-folder'), null);
  assert.equal(state.cloudRecovery.events.has('pending-edit'), false, 'only tombstones belong in the delete journal');
  await restorePendingDeletesFromIndexedDb('account-1');
  state.cloudRecovery.events.delete('deleted-event');
  state.cloudRecovery.folders.delete('deleted-folder');
  persistPendingDeletes('account-1');
  assert.deepEqual(JSON.parse(localStorage.getItem(key)), [], 'successful deletes clear the durable journal');

  state.cloudRecovery.events.set('offline-delete', null);
  denyLocalStorageWrites = true;
  await persistPendingDeletes('account-1');
  assert.deepEqual(await idbGet(key), [{{collection:'events',id:'offline-delete'}}], 'IndexedDB is the persistence fallback when localStorage is blocked');
  state.cloudRecovery = {{events:new Map(),folders:new Map()}};
  await restorePendingDeletesFromIndexedDb('account-1');
  assert.equal(state.cloudRecovery.events.get('offline-delete'), null, 'the fallback restores the pending tombstone');
  state.cloudRecovery.events.delete('offline-delete');
  await persistPendingDeletes('account-1');
  state.cloudRecovery = {{events:new Map(),folders:new Map()}};
  await restorePendingDeletesFromIndexedDb('account-1');
  assert.equal(state.cloudRecovery.events.size, 0, 'the IndexedDB backup reflects the acknowledged delete');
  console.log('PASS: delete tombstones persist, restore per account, fall back to IndexedDB, exclude normal edits, and clear after acknowledgement');
}})().catch(error=>{{console.error(error);process.exit(1)}});
'''
result = subprocess.run([node, '-e', script], capture_output=True, text=True)
if result.returncode:
    print(result.stdout, end='')
    print(result.stderr, end='')
    print('FAIL: pending-delete persistence behavior')
    sys.exit(result.returncode)
print(result.stdout, end='')
