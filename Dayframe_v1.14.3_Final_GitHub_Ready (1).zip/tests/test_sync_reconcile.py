"""Exercise the release's actual JS reconciliation helpers with a small Node test."""
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text(encoding='utf-8')
node = shutil.which('node')
if not node:
    print('SKIP: Node.js is not installed; reconciliation behavior was not executed')
    sys.exit(0)

def extract(start, end):
    match = re.search(re.escape(start) + r'(.*?)' + re.escape(end), html, re.S)
    if not match:
        raise SystemExit(f'FAIL: Could not extract {start}')
    return start + match.group(1)

record_timestamp = extract('function recordTimestamp(item){', '\nfunction mergeRecoveredDocs')
reconcile = extract('function reconcileCloudItems(remoteItems,localItems){', '\nfunction pendingRecoveryCount')
merge_pending = extract('function mergeCloudWithPending(remoteItems,collectionName){', '\nfunction cleanCloudRecord')
clean_record = extract('function cleanCloudRecord(value){', '\nfunction eventsCollection')
script = f'''\nconst assert = require('node:assert/strict');\n{record_timestamp}\n{reconcile}\n{clean_record}\n{merge_pending}\nlet result = reconcileCloudItems(\n [{{id:'remote-old', title:'Old cloud copy', updatedAt:'2026-01-01T00:00:00.000Z'}}, {{id:'cloud-newer', title:'Newer cloud copy', updatedAt:'2026-03-01T00:00:00.000Z'}}, {{id:'legacy-folder', name:'Old cloud name', createdAt:'2026-02-03T00:00:00.000Z'}}],\n [{{id:'remote-old', title:'Fresh local copy', updatedAt:'2026-02-01T00:00:00.000Z'}}, {{id:'local-only', title:'Desktop only', createdAt:'2026-02-02T00:00:00.000Z'}}, {{id:'legacy-folder', name:'Desktop rename', createdAt:'2026-02-03T00:00:00.000Z'}}]\n);\nassert.equal(result.items.find(x=>x.id==='remote-old').title, 'Fresh local copy');\nassert.equal(result.items.find(x=>x.id==='local-only').title, 'Desktop only');
assert.equal(result.items.find(x=>x.id==='legacy-folder').name, 'Desktop rename');\nassert.equal(result.items.find(x=>x.id==='cloud-newer').title, 'Newer cloud copy');\nassert.deepEqual(result.toUpload.map(x=>x.id).sort(), ['legacy-folder','local-only','remote-old']);\nconst state = {{cloudRecovery:{{events:new Map([['pending-newer', {{id:'pending-newer', title:'Local change', updatedAt:'2026-04-01T00:00:00.000Z'}}], ['pending-delete', null]])}}}};\nlet merged = mergeCloudWithPending([{{id:'pending-newer', title:'Old cloud data', updatedAt:'2026-03-01T00:00:00.000Z'}}, {{id:'pending-delete', title:'To be deleted', updatedAt:'2026-03-01T00:00:00.000Z'}}], 'events');\nassert.equal(merged.find(x=>x.id==='pending-newer').title, 'Local change');\nassert.equal(merged.some(x=>x.id==='pending-delete'), false);\nassert.equal(state.cloudRecovery.events.has('pending-newer'), true);\nconsole.log('PASS: reconciliation preserves local-only tasks and newer local edits, prefers newer cloud records, and retains pending edits/deletes');\n'''
result = subprocess.run([node, '-e', script], capture_output=True, text=True)
if result.returncode:
    print(result.stdout, end='')
    print(result.stderr, end='')
    print('FAIL: cloud reconciliation behavior')
    sys.exit(result.returncode)
print(result.stdout, end='')
