"""Extract the inline app module and run Node's syntax checker."""
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parents[1]
html = (root / 'index.html').read_text(encoding='utf-8')
match = re.search(r'<script type="module">(.*?)</script>', html, re.S)
if not match:
    print('FAIL: Could not locate the application module')
    sys.exit(1)
node = shutil.which('node')
if not node:
    print('SKIP: Node.js is not installed; JavaScript syntax was not checked')
    sys.exit(0)
with tempfile.NamedTemporaryFile('w', suffix='.mjs', encoding='utf-8', delete=False) as f:
    f.write(match.group(1))
    temp_path = Path(f.name)
try:
    result = subprocess.run([node, '--check', str(temp_path)], text=True, capture_output=True)
    if result.returncode:
        print(result.stdout, end='')
        print(result.stderr, end='')
        print('FAIL: JavaScript syntax check')
        sys.exit(result.returncode)
    print('PASS: Application module JavaScript syntax')
finally:
    temp_path.unlink(missing_ok=True)
