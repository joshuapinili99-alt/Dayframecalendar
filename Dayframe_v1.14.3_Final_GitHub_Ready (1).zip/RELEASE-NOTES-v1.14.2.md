# Dayframe v1.14.2 — Mobile and quiet autosave improvements

## Mobile experience
- Phones and narrow screens open directly into the Tasks list, showing all open tasks across dates as readable full-width rows. Opening Calendar on a phone defaults to the 14-day Agenda view.
- Improved overflow protection, header sizing, toolbar wrapping, form layout, and touch behavior at common phone widths.
- Desktop continues to use the Month calendar by default. The calendar mode remains local to each device.

## Background Firebase saving
- Planner mutations are saved to the local account cache immediately and synchronized to Firestore without blocking the interface. Realtime listeners attach without waiting for an initial server read; local cache snapshots display promptly, while recovery uploads wait for a server-confirmed snapshot.
- Routine successful saves no longer show toast popups or per-write “Saving changes” text. Transient cloud failures retry quietly with bounded backoff; permission/configuration errors remain visible.
- Notes autosave while typing; the status distinguishes a local save from Firebase confirmation.
- Saves that resume after an account change are stopped before a write can proceed under a different active session.

## Account privacy
- Firestore and Storage remain owner-scoped by Firebase UID.
- The sign-in interface clearly warns that all devices/persons using the same Login ID and password share that account's data. Each person should use a distinct account; the same account should only be used across devices belonging to that user.

## Validation
- Static regression suite, sync reconciliation tests, pending-delete recovery tests, JavaScript syntax check, and archive integrity check are included/run as part of the release workflow.
- Live sign-in, real Firestore permissions, and actual device-to-device behavior still require checking in the configured Firebase project.

## Firestore rule integration

The supplied owner-only Firestore rule is present in `firestore.rules`. The new root `firebase.json` and `.firebaserc` files point Firebase CLI deployments at the correct rule file and Firebase project. From the repository root, run `npx firebase-tools login` and `npx firebase-tools deploy --only firestore:rules` to publish it. GitHub Pages deployment by itself does not publish Firebase security rules.
