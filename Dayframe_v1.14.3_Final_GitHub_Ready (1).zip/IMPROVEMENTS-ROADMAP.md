# Dayframe improvement roadmap · v1.14.3

## Delivered in v1.14.3

- Reliable in-app delete confirmation for tasks, notes, checklists, and folders.
- One-tap checklist creation with inline checklist item entry.
- Aesthetic due-soon popups while the app is open, with optional system notifications.
- Adaptive PNG export resolution and share-sheet support on compatible mobile browsers.
- Inherits the v1.14.2 mobile-first Tasks/Agenda experience and quiet Firebase autosave.

## Included from v1.14.2

- Mobile opens to the full Tasks list; Calendar opens in a readable Agenda mode.
- Routine saves sync to Firebase in the background without success popups or per-write loading text, with quiet bounded retries for transient failures. Firebase listeners attach immediately while protecting newer server records from cache-only recovery writes.
- Account switches are guarded and the UI explains that sharing credentials shares planner data.

## Delivered in v1.14.1
- Reconcile the freshest local browser cache with Firestore, even when the cloud already contains some records.
- Recover desktop-local tasks/folders that were never uploaded, plus newer local edits, by queuing missing/newer records for cloud writes.
- Preserve pending local edits and deletes when live Firestore snapshots arrive.
- Retry pending writes on reconnection or when the page becomes visible, while preserving the local copy if cloud writes fail.
- Select the freshest full local cache snapshot to avoid resurrecting deleted items from a stale cache.
- Add account reference information to the sync-status message to help verify the same Login ID is used on each device.
- Persist pending delete tombstones in localStorage with an IndexedDB fallback so offline/failed deletions survive reloads and cannot be re-uploaded from stale caches.
- Add regression tests for reconciliation, pending edits/deletes, and release deployment.

## Existing features retained
- Private Login ID + password for new users, with support for older email-based accounts.
- Single responsive HTML codebase, Firebase Authentication, Firestore live listeners, and Firebase Storage uploads.
- Mobile layout hardening, calendar PNG export, refreshed logo, installable-app icons, and GitHub Pages deployment workflow.

## Recommended next improvements
1. **Account recovery:** ID-only users have no email recovery channel. Add a verified recovery method or a server-side account recovery process before relying on the app for important data.
2. **Conflict handling:** add version fields or a conflict banner when two devices edit the same record at once, since a single Firestore document uses last-write-wins behavior.
3. **Attachment lifecycle:** add retry UI for failed uploads and periodic cleanup for orphaned Storage files.
4. **Push reminders:** browser notifications currently require browser support, permission, and the app to be open. Reliable notifications while closed require a push/backend workflow.
5. **Release verification:** test account creation/sign-in, record edit/delete, attachment upload/download, and device-to-device updates on the live Firebase project and on a real iPhone and Android phone.

## Setup dependency

A Firebase config file does not itself turn on project services. Follow `FIREBASE-SETUP.md` to enable Authentication, create Firestore and Storage, publish the security rules, and authorize your HTTPS hostname.
