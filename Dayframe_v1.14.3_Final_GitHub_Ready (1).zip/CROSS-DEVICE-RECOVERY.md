# Recover desktop tasks so they appear on mobile

Dayframe v1.14.3 includes the v1.14.1 sync-recovery fixes and improves mobile task visibility and background saving. It fixes a case where some desktop-only tasks could be ignored if Firestore already contained other items. It now reconciles the freshest complete local cache with Firebase on startup and from live Firestore snapshots. Missing local-only records and newer local edits are queued for cloud upload; failed writes remain visible locally and retry when connectivity returns.

## Recommended recovery sequence

1. Deploy the complete v1.14.3 ZIP to the same GitHub repository and wait for the GitHub Pages workflow to finish.
2. Open Dayframe in the **original desktop browser where the missing tasks were created**. Do not clear browser data or uninstall the app first.
3. Sign in online using the exact Firebase Login ID that should be shared with mobile. Wait until the sync indicator no longer reports items awaiting cloud sync.
4. Tap the sync indicator on desktop and mobile to compare the Login ID and the last six characters of the account reference. These should match.
5. Refresh Dayframe on mobile. The same Firestore account should now return the recovered tasks and folders.

## If tasks are still missing

- If the short account references differ, the devices are signed into different Firebase accounts. Sign out and use the same Login ID; different accounts do not share planner collections automatically.
- If the sync indicator shows an error or items remain pending, check that Email/Password Authentication is enabled, Firestore is created, the supplied `firestore.rules` are published, and the app is hosted at the authorized HTTPS domain.
- If the data existed only in a different/older browser profile, that browser profile must be opened too. Browser-local data cannot be recovered from another device unless it was successfully uploaded to Firebase.
- Keep the desktop browser cache intact until recovery is confirmed on mobile.

Static tests passed for the reconciliation logic, but live cloud syncing still depends on Firebase service configuration, account identity, and successful Firestore writes.
